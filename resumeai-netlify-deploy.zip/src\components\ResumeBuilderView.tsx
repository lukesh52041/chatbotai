import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Download,
  Save,
  RefreshCw,
  Check,
  AlertCircle,
  Loader2,
  Plus,
  Trash2,
  Eye,
  FileEdit,
  Wand2,
} from 'lucide-react';
import {
  ExperienceLevel,
  ResumeBuilderInput,
  ResumeData,
  ResumeTemplateId,
} from '../types';
import {
  exportResumeToPdf,
  generateId,
  getApiHeaders,
  SAMPLE_BUILDER_INPUT,
} from '../utils/resumeHelpers';
import { ResumePreview } from './ResumePreview';

interface ResumeBuilderViewProps {
  initialResume: ResumeData | null;
  onSaveResume: (resume: ResumeData) => void;
}

const EMPTY_INPUT: ResumeBuilderInput = {
  fullName: '',
  email: '',
  phone: '',
  location: '',
  linkedin: '',
  portfolio: '',
  targetRole: '',
  experienceLevel: 'Fresher',
  careerObjectiveInput: '',
  educationRaw: '',
  skillsRaw: '',
  projectsRaw: '',
  internshipsRaw: '',
  certificationsRaw: '',
  achievementsRaw: '',
  customInstruction: '',
};

function createEmptyResume(): ResumeData {
  return {
    id: generateId(),
    title: 'Untitled Resume',
    template: 'executive-blue',
    updatedAt: new Date().toISOString(),
    experienceLevel: 'Fresher',
    targetRole: '',
    personal: {
      fullName: '',
      email: '',
      phone: '',
      location: '',
      linkedin: '',
      portfolio: '',
    },
    summary: '',
    careerObjective: '',
    education: [],
    skills: { technical: [], tools: [], soft: [] },
    projects: [],
    internships: [],
    certifications: [],
    achievements: [],
  };
}

function resumeToBuilderInput(r: ResumeData): ResumeBuilderInput {
  return {
    fullName: r.personal.fullName,
    email: r.personal.email,
    phone: r.personal.phone,
    location: r.personal.location,
    linkedin: r.personal.linkedin,
    portfolio: r.personal.portfolio,
    targetRole: r.targetRole,
    experienceLevel: r.experienceLevel,
    careerObjectiveInput: r.careerObjective || r.summary,
    educationRaw: r.education
      .map((e) => `${e.degree}, ${e.institution} (${e.duration}) ${e.grade ? `- ${e.grade}` : ''} ${e.highlights}`)
      .join('\n'),
    skillsRaw: [...r.skills.technical, ...r.skills.tools, ...r.skills.soft].join(', '),
    projectsRaw: r.projects
      .map((p) => `${p.title} (${p.techStack}) - ${p.bullets.join('; ')}`)
      .join('\n'),
    internshipsRaw: r.internships
      .map((i) => `${i.role} at ${i.company} (${i.duration}) - ${i.bullets.join('; ')}`)
      .join('\n'),
    certificationsRaw: r.certifications.join('\n'),
    achievementsRaw: r.achievements.join('\n'),
    customInstruction: '',
  };
}

export const ResumeBuilderView: React.FC<ResumeBuilderViewProps> = ({
  initialResume,
  onSaveResume,
}) => {
  const [formInput, setFormInput] = useState<ResumeBuilderInput>(
    initialResume ? resumeToBuilderInput(initialResume) : EMPTY_INPUT
  );
  const [resume, setResume] = useState<ResumeData>(
    initialResume ?? createEmptyResume()
  );
  const [editorMode, setEditorMode] = useState<'intake' | 'customize'>(
    initialResume ? 'customize' : 'intake'
  );
  const [mobilePane, setMobilePane] = useState<'edit' | 'preview'>('edit');
  const [isGenerating, setIsGenerating] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState('Generating your professional resume...');
  const [error, setError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [savedNotice, setSavedNotice] = useState(false);
  const [regeneratePrompt, setRegeneratePrompt] = useState('');

  const inFlightRef = useRef(false);
  const loadedResumeIdRef = useRef<string | null>(initialResume?.id ?? null);
  const lastCustomInstructionRef = useRef<string | undefined>(undefined);

  useEffect(() => {
    if (initialResume) {
      if (initialResume.id === loadedResumeIdRef.current) {
        return;
      }
      loadedResumeIdRef.current = initialResume.id;
      setResume(initialResume);
      setFormInput(resumeToBuilderInput(initialResume));
      setEditorMode('customize');
    } else if (loadedResumeIdRef.current !== null) {
      loadedResumeIdRef.current = null;
      const fresh = createEmptyResume();
      setResume(fresh);
      setFormInput(EMPTY_INPUT);
      setEditorMode('intake');
    }
    setError(null);
    setFieldErrors({});
  }, [initialResume]);

  const validateIntake = (): boolean => {
    const errs: Record<string, string> = {};
    if (!formInput.fullName.trim()) {
      errs.fullName = 'Full name is required.';
    }
    if (!formInput.email.trim()) {
      errs.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formInput.email.trim())) {
      errs.email = 'Enter a valid email address.';
    }
    if (
      !formInput.educationRaw.trim() &&
      !formInput.skillsRaw.trim() &&
      !formInput.projectsRaw.trim() &&
      !formInput.internshipsRaw.trim()
    ) {
      errs.educationRaw =
        'Please provide at least your education, skills, projects, or internships so AI can build your resume.';
    }
    setFieldErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleGenerateWithAI = async (customInstruction?: string) => {
    if (inFlightRef.current) {
      return;
    }
    if (!validateIntake()) {
      setEditorMode('intake');
      setError('Please fix the highlighted fields before generating your resume.');
      return;
    }
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      setError('You appear to be offline. Please check your internet connection and retry.');
      return;
    }

    inFlightRef.current = true;
    lastCustomInstructionRef.current = customInstruction;
    setIsGenerating(true);
    setLoadingStatus('Generating your professional resume...');
    setError(null);

    const controller = new AbortController();
    const timeoutId = window.setTimeout(() => controller.abort(), 30000);

    try {
      const response = await fetch('/api/resume/generate', {
        method: 'POST',
        headers: getApiHeaders({ 'Content-Type': 'application/json' }),
        signal: controller.signal,
        body: JSON.stringify({
          ...formInput,
          stream: true,
          customInstruction: customInstruction ?? formInput.customInstruction,
        }),
      });

      if (!response.ok) {
        const errBody = await response.json().catch(() => ({}));
        if (response.status === 429) {
          throw new Error('AI rate limit reached. Please wait a few seconds and click Retry.');
        }
        throw new Error(errBody.error || `Server error (${response.status}). Failed to generate resume.`);
      }

      const contentType = response.headers.get('content-type') || '';
      let g: Record<string, any> | null = null;

      if (contentType.includes('text/event-stream') && response.body) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });

          const events = buffer.split('\n\n');
          buffer = events.pop() ?? '';

          for (const evt of events) {
            const line = evt.trim();
            if (!line.startsWith('data:')) continue;
            const jsonStr = line.slice(5).trim();
            if (!jsonStr) continue;
            const parsed = JSON.parse(jsonStr);
            if (parsed.error) {
              throw new Error(parsed.error);
            }
            if (parsed.stage) {
              setLoadingStatus(parsed.stage);
            }
            if (parsed.done && parsed.generated) {
              g = parsed.generated;
            }
          }
        }
      } else {
        const data = await response.json();
        g = data.generated ?? null;
      }

      if (!g || typeof g !== 'object' || Object.keys(g).length === 0) {
        throw new Error('Received an empty response from Gemini AI. Please click Retry.');
      }

      const updatedResume: ResumeData = {
        ...resume,
        title: `${formInput.fullName.trim()} — ${formInput.targetRole.trim() || 'Resume'}`,
        updatedAt: new Date().toISOString(),
        experienceLevel: formInput.experienceLevel,
        targetRole: formInput.targetRole.trim(),
        personal: {
          fullName: formInput.fullName.trim(),
          email: formInput.email.trim(),
          phone: formInput.phone.trim(),
          location: formInput.location.trim(),
          linkedin: formInput.linkedin.trim(),
          portfolio: formInput.portfolio.trim(),
        },
        summary: g.summary || '',
        careerObjective: g.careerObjective || '',
        education: (g.education || []).map((e: Omit<ResumeData['education'][number], 'id'>) => ({
          id: generateId(),
          ...e,
        })),
        skills: {
          technical: g.skills?.technical || [],
          tools: g.skills?.tools || [],
          soft: g.skills?.soft || [],
        },
        projects: (g.projects || []).map((p: Omit<ResumeData['projects'][number], 'id'>) => ({
          id: generateId(),
          ...p,
        })),
        internships: (g.internships || []).map((i: Omit<ResumeData['internships'][number], 'id'>) => ({
          id: generateId(),
          ...i,
        })),
        certifications: g.certifications || [],
        achievements: g.achievements || [],
      };

      loadedResumeIdRef.current = updatedResume.id;
      setResume(updatedResume);
      onSaveResume(updatedResume);
      setEditorMode('customize');
      if (typeof window !== 'undefined' && window.innerWidth < 1024) {
        setMobilePane('preview');
      }
      setSavedNotice(true);
      setTimeout(() => setSavedNotice(false), 2500);
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        setError('Request timed out after 30 seconds. Please check your connection and click Retry.');
      } else if (err instanceof TypeError) {
        setError('Network connection failure while contacting the server. Please check connectivity and click Retry.');
      } else {
        setError(err instanceof Error ? err.message : 'Unable to generate resume right now.');
      }
    } finally {
      window.clearTimeout(timeoutId);
      inFlightRef.current = false;
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    if (!resume.personal.fullName.trim()) {
      setError('Please enter your name before saving.');
      return;
    }
    const updated: ResumeData = {
      ...resume,
      title: resume.title || `${resume.personal.fullName} — ${resume.targetRole || 'Resume'}`,
      updatedAt: new Date().toISOString(),
    };
    setResume(updated);
    onSaveResume(updated);
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  const handleFillSample = () => {
    setFormInput(SAMPLE_BUILDER_INPUT);
    setFieldErrors({});
    setError(null);
  };

  const updatePersonal = (key: keyof ResumeData['personal'], value: string) => {
    setResume((prev) => ({
      ...prev,
      personal: { ...prev.personal, [key]: value },
    }));
  };

  const templates: Array<{ id: ResumeTemplateId; name: string; desc: string }> = [
    { id: 'executive-blue', name: 'Executive Blue', desc: 'Clean corporate blue accent' },
    { id: 'classic-academic', name: 'Classic Academic', desc: 'Traditional serif ATS layout' },
    { id: 'minimalist-slate', name: 'Minimalist Slate', desc: 'Crisp modern geometric sans' },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-5">
      {/* Top Action Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex items-center p-1 rounded-lg bg-slate-100 dark:bg-slate-800">
            <button
              type="button"
              onClick={() => setEditorMode('intake')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                editorMode === 'intake'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5" />
              1. AI Input Form
            </button>
            <button
              type="button"
              onClick={() => setEditorMode('customize')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                editorMode === 'customize'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <FileEdit className="w-3.5 h-3.5" />
              2. Customize Sections
            </button>
          </div>

          {/* Mobile Edit/Preview Switch */}
          <div className="inline-flex lg:hidden items-center p-1 rounded-lg bg-slate-100 dark:bg-slate-800">
            <button
              type="button"
              onClick={() => setMobilePane('edit')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer ${
                mobilePane === 'edit'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Editor
            </button>
            <button
              type="button"
              onClick={() => setMobilePane('preview')}
              className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer ${
                mobilePane === 'preview'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              Preview
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleSave}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
          >
            {savedNotice ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Save className="w-3.5 h-3.5" />}
            {savedNotice ? 'Saved' : 'Save Resume'}
          </button>
          <button
            type="button"
            onClick={() => exportResumeToPdf(resume)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            Download PDF
          </button>
        </div>
      </div>

      {error && (
        <div
          role="alert"
          className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm"
        >
          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            type="button"
            disabled={isGenerating}
            onClick={() => handleGenerateWithAI(lastCustomInstructionRef.current)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white text-xs font-semibold transition-colors cursor-pointer shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
        </div>
      )}

      {/* Split Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Pane: Form / Section Editor */}
        <div className={`lg:col-span-5 space-y-5 ${mobilePane === 'preview' ? 'hidden lg:block' : 'block'}`}>
          {editorMode === 'intake' ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 space-y-5">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                    Candidate Details
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Enter rough notes — Gemini formats them into strong resume bullets.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleFillSample}
                  className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Fill Sample Profile
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formInput.fullName}
                    onChange={(e) => setFormInput({ ...formInput, fullName: e.target.value })}
                    placeholder="e.g. Aarav Sharma"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  {fieldErrors.fullName && (
                    <p className="mt-1 text-xs text-red-600 dark:text-red-400">{fieldErrors.fullName}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Email <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    value={formInput.email}
                    onChange={(e) => setFormInput({ ...formInput, email: e.target.value })}
                    placeholder="you@example.com"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  {fieldErrors.email && (
                    <p className="mt-1 text-xs text-red-600 dark:text-red-400">{fieldErrors.email}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={formInput.phone}
                    onChange={(e) => setFormInput({ ...formInput, phone: e.target.value })}
                    placeholder="+91 98765 43210"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Location
                  </label>
                  <input
                    type="text"
                    value={formInput.location}
                    onChange={(e) => setFormInput({ ...formInput, location: e.target.value })}
                    placeholder="City, Country"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Experience Level
                  </label>
                  <select
                    value={formInput.experienceLevel}
                    onChange={(e) =>
                      setFormInput({
                        ...formInput,
                        experienceLevel: e.target.value as ExperienceLevel,
                      })
                    }
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="Student">Student</option>
                    <option value="Fresher">Fresher (0-1 yrs)</option>
                    <option value="Experienced">Experienced</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Target Job Title
                  </label>
                  <input
                    type="text"
                    value={formInput.targetRole}
                    onChange={(e) => setFormInput({ ...formInput, targetRole: e.target.value })}
                    placeholder="e.g. Junior Software Developer, Data Analyst Intern"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    LinkedIn URL
                  </label>
                  <input
                    type="text"
                    value={formInput.linkedin}
                    onChange={(e) => setFormInput({ ...formInput, linkedin: e.target.value })}
                    placeholder="linkedin.com/in/username"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    GitHub / Portfolio
                  </label>
                  <input
                    type="text"
                    value={formInput.portfolio}
                    onChange={(e) => setFormInput({ ...formInput, portfolio: e.target.value })}
                    placeholder="github.com/username"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Career Objective (Optional — AI will refine or write one)
                  </label>
                  <textarea
                    rows={2}
                    value={formInput.careerObjectiveInput}
                    onChange={(e) =>
                      setFormInput({ ...formInput, careerObjectiveInput: e.target.value })
                    }
                    placeholder="Briefly describe your career goal or strengths..."
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Education (Degree, College, Years, CGPA/Percentage)
                  </label>
                  <textarea
                    rows={2}
                    value={formInput.educationRaw}
                    onChange={(e) => setFormInput({ ...formInput, educationRaw: e.target.value })}
                    placeholder="e.g. B.Tech CSE, XYZ Institute (2022-2026), CGPA 8.7/10"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  {fieldErrors.educationRaw && (
                    <p className="mt-1 text-xs text-red-600 dark:text-red-400">{fieldErrors.educationRaw}</p>
                  )}
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Skills (Comma-separated technical & soft skills)
                  </label>
                  <textarea
                    rows={2}
                    value={formInput.skillsRaw}
                    onChange={(e) => setFormInput({ ...formInput, skillsRaw: e.target.value })}
                    placeholder="Python, React, SQL, Git, Communication, Problem Solving"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Projects (Title, tech used, what you built)
                  </label>
                  <textarea
                    rows={3}
                    value={formInput.projectsRaw}
                    onChange={(e) => setFormInput({ ...formInput, projectsRaw: e.target.value })}
                    placeholder="1. Library Management System (Java, MySQL) - Built search and borrow tracking..."
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Internships / Experience (Leave blank if fresher without internships)
                  </label>
                  <textarea
                    rows={2}
                    value={formInput.internshipsRaw}
                    onChange={(e) => setFormInput({ ...formInput, internshipsRaw: e.target.value })}
                    placeholder="Web Dev Intern at ABC Tech (Summer 2025) - Built landing pages..."
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Certifications
                  </label>
                  <textarea
                    rows={2}
                    value={formInput.certificationsRaw}
                    onChange={(e) =>
                      setFormInput({ ...formInput, certificationsRaw: e.target.value })
                    }
                    placeholder="AWS Cloud Practitioner, Coursera Python..."
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Achievements
                  </label>
                  <textarea
                    rows={2}
                    value={formInput.achievementsRaw}
                    onChange={(e) =>
                      setFormInput({ ...formInput, achievementsRaw: e.target.value })
                    }
                    placeholder="Hackathon finalist, Dean's List, 300+ LeetCode..."
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <button
                type="button"
                disabled={isGenerating}
                onClick={() => handleGenerateWithAI()}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold transition-colors cursor-pointer"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    {loadingStatus}
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Generate Resume
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Regenerate with AI Instruction */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-2.5">
                <label className="block text-xs font-semibold text-slate-900 dark:text-white">
                  Regenerate or Tailor with Gemini AI
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={regeneratePrompt}
                    onChange={(e) => setRegeneratePrompt(e.target.value)}
                    placeholder="e.g. Make bullets concise & focus on React/Node.js"
                    className="flex-1 px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    type="button"
                    disabled={isGenerating}
                    onClick={() => handleGenerateWithAI(regeneratePrompt)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
                  >
                    {isGenerating ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <RefreshCw className="w-3.5 h-3.5" />
                    )}
                    Regenerate
                  </button>
                </div>
              </div>

              {/* Direct Live Section Customization */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-5">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                  Live Resume Editor
                </h3>

                {/* Resume Title & Header */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Saved Resume Title
                    </label>
                    <input
                      type="text"
                      value={resume.title}
                      onChange={(e) => setResume({ ...resume, title: e.target.value })}
                      className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      value={resume.personal.fullName}
                      onChange={(e) => updatePersonal('fullName', e.target.value)}
                      className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Target Role
                    </label>
                    <input
                      type="text"
                      value={resume.targetRole}
                      onChange={(e) => setResume({ ...resume, targetRole: e.target.value })}
                      className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      value={resume.personal.email}
                      onChange={(e) => updatePersonal('email', e.target.value)}
                      className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Phone
                    </label>
                    <input
                      type="text"
                      value={resume.personal.phone}
                      onChange={(e) => updatePersonal('phone', e.target.value)}
                      className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>

                {/* Professional Summary & Career Objective */}
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Professional Summary
                    </label>
                    <textarea
                      rows={3}
                      value={resume.summary}
                      onChange={(e) => setResume({ ...resume, summary: e.target.value })}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Career Objective (Optional)
                    </label>
                    <textarea
                      rows={2}
                      value={resume.careerObjective || ''}
                      onChange={(e) => setResume({ ...resume, careerObjective: e.target.value })}
                      placeholder="Leave empty to omit Career Objective section"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>

                {/* Skills quick edit */}
                <div className="space-y-2.5">
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                    Technical Skills (comma-separated)
                  </label>
                  <input
                    type="text"
                    value={resume.skills.technical.join(', ')}
                    onChange={(e) =>
                      setResume({
                        ...resume,
                        skills: {
                          ...resume.skills,
                          technical: e.target.value
                            .split(',')
                            .map((s) => s.trim())
                            .filter(Boolean),
                        },
                      })
                    }
                    className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                  />
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                    Tools & Platforms (comma-separated)
                  </label>
                  <input
                    type="text"
                    value={resume.skills.tools.join(', ')}
                    onChange={(e) =>
                      setResume({
                        ...resume,
                        skills: {
                          ...resume.skills,
                          tools: e.target.value
                            .split(',')
                            .map((s) => s.trim())
                            .filter(Boolean),
                        },
                      })
                    }
                    className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                  />
                </div>

                {/* Projects Editor */}
                <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-900 dark:text-white">
                      Projects
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setResume({
                          ...resume,
                          projects: [
                            ...resume.projects,
                            { id: generateId(), title: 'New Project', techStack: '', link: '', bullets: [''] },
                          ],
                        })
                      }
                      className="inline-flex items-center gap-1 text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Project
                    </button>
                  </div>
                  {resume.projects.map((proj, idx) => (
                    <div
                      key={proj.id}
                      className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <input
                          type="text"
                          value={proj.title}
                          onChange={(e) => {
                            const next = [...resume.projects];
                            next[idx] = { ...proj, title: e.target.value };
                            setResume({ ...resume, projects: next });
                          }}
                          className="flex-1 px-2.5 py-1 text-xs font-semibold rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setResume({
                              ...resume,
                              projects: resume.projects.filter((p) => p.id !== proj.id),
                            })
                          }
                          aria-label="Remove project"
                          className="p-1 text-slate-400 hover:text-red-500 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <input
                        type="text"
                        value={proj.techStack}
                        placeholder="Tech stack"
                        onChange={(e) => {
                          const next = [...resume.projects];
                          next[idx] = { ...proj, techStack: e.target.value };
                          setResume({ ...resume, projects: next });
                        }}
                        className="w-full px-2.5 py-1 text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200"
                      />
                      <textarea
                        rows={2}
                        value={proj.bullets.join('\n')}
                        placeholder="One bullet per line"
                        onChange={(e) => {
                          const next = [...resume.projects];
                          next[idx] = { ...proj, bullets: e.target.value.split('\n') };
                          setResume({ ...resume, projects: next });
                        }}
                        className="w-full px-2.5 py-1 text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200"
                      />
                    </div>
                  ))}
                </div>

                {/* Internships Editor */}
                <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-900 dark:text-white">
                      Experience & Internships
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setResume({
                          ...resume,
                          internships: [
                            ...resume.internships,
                            {
                              id: generateId(),
                              role: 'Intern',
                              company: 'Company Name',
                              duration: 'May 2025 - Jul 2025',
                              location: 'Remote',
                              bullets: [''],
                            },
                          ],
                        })
                      }
                      className="inline-flex items-center gap-1 text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Experience
                    </button>
                  </div>
                  {resume.internships.map((intern, idx) => (
                    <div
                      key={intern.id}
                      className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <input
                          type="text"
                          value={intern.role}
                          onChange={(e) => {
                            const next = [...resume.internships];
                            next[idx] = { ...intern, role: e.target.value };
                            setResume({ ...resume, internships: next });
                          }}
                          className="flex-1 px-2.5 py-1 text-xs font-semibold rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setResume({
                              ...resume,
                              internships: resume.internships.filter((i) => i.id !== intern.id),
                            })
                          }
                          aria-label="Remove internship"
                          className="p-1 text-slate-400 hover:text-red-500 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={intern.company}
                          placeholder="Company"
                          onChange={(e) => {
                            const next = [...resume.internships];
                            next[idx] = { ...intern, company: e.target.value };
                            setResume({ ...resume, internships: next });
                          }}
                          className="px-2.5 py-1 text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200"
                        />
                        <input
                          type="text"
                          value={intern.duration}
                          placeholder="Duration"
                          onChange={(e) => {
                            const next = [...resume.internships];
                            next[idx] = { ...intern, duration: e.target.value };
                            setResume({ ...resume, internships: next });
                          }}
                          className="px-2.5 py-1 text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200"
                        />
                      </div>
                      <textarea
                        rows={2}
                        value={intern.bullets.join('\n')}
                        placeholder="One bullet per line"
                        onChange={(e) => {
                          const next = [...resume.internships];
                          next[idx] = { ...intern, bullets: e.target.value.split('\n') };
                          setResume({ ...resume, internships: next });
                        }}
                        className="w-full px-2.5 py-1 text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200"
                      />
                    </div>
                  ))}
                </div>
                {/* Certifications & Achievements */}
                <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Certifications (one per line)
                    </label>
                    <textarea
                      rows={2}
                      value={resume.certifications.join('\n')}
                      onChange={(e) =>
                        setResume({
                          ...resume,
                          certifications: e.target.value.split('\n').filter((s) => s.trim() !== ''),
                        })
                      }
                      className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Achievements (one per line)
                    </label>
                    <textarea
                      rows={2}
                      value={resume.achievements.join('\n')}
                      onChange={(e) =>
                        setResume({
                          ...resume,
                          achievements: e.target.value.split('\n').filter((s) => s.trim() !== ''),
                        })
                      }
                      className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Pane: Template Switcher & Live A4 Preview */}
        <div className={`lg:col-span-7 space-y-4 ${mobilePane === 'edit' ? 'hidden lg:block' : 'block'}`}>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 px-1">
              Template Style
            </span>
            <div className="flex flex-wrap items-center gap-1.5">
              {templates.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setResume((prev) => ({ ...prev, template: t.id }))}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    resume.template === t.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {t.name}
                </button>
              ))}
            </div>
          </div>

          <p className="text-[11px] text-slate-500 dark:text-slate-400 text-center lg:hidden">
            Tip: Scroll horizontally to view the full A4 layout
          </p>
          <div className="relative overflow-x-auto pb-4">
            {isGenerating && (
              <div className="absolute inset-0 z-10 bg-white/85 dark:bg-slate-950/85 backdrop-blur-[1px] rounded-md flex flex-col items-center justify-center gap-3 p-6 text-center">
                <Loader2 className="w-7 h-7 animate-spin text-blue-600 dark:text-blue-400" />
                <div className="space-y-1">
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">
                    {loadingStatus}
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Structuring your sections without inventing credentials
                  </p>
                </div>
              </div>
            )}
            <ResumePreview resume={resume} />
          </div>
        </div>
      </div>
    </div>
  );
};
