import React from 'react';
import {
  FilePlus2,
  FileSearch,
  MessageSquare,
  Target,
  Mic,
  Download,
  Pencil,
  Trash2,
  ArrowRight,
  FileText,
} from 'lucide-react';
import { AppView, ResumeData } from '../types';
import { formatShortDate } from '../utils/resumeHelpers';

interface DashboardViewProps {
  resumes: ResumeData[];
  onNavigate: (view: AppView) => void;
  onCreateNew: () => void;
  onEditResume: (resume: ResumeData) => void;
  onDeleteResume: (id: string) => void;
  onDownloadPdf: (resume: ResumeData) => void;
  onSendToAts: (resume: ResumeData) => void;
  onSendToInterview: (resume: ResumeData) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  resumes,
  onNavigate,
  onCreateNew,
  onEditResume,
  onDeleteResume,
  onDownloadPdf,
  onSendToAts,
  onSendToInterview,
}) => {
  const quickTools = [
    {
      id: 'analyzer' as AppView,
      title: 'Analyze My Resume',
      description: 'Upload a PDF to receive a score out of 100, grammar fixes, and bullet rewrites.',
      icon: FileSearch,
      actionLabel: 'Upload & Analyze',
    },
    {
      id: 'chatbot' as AppView,
      title: 'Chat with AI',
      description: 'Ask career questions, improve your LinkedIn, or refine project descriptions.',
      icon: MessageSquare,
      actionLabel: 'Open Assistant',
    },
    {
      id: 'ats' as AppView,
      title: 'ATS Score Checker',
      description: 'Compare your resume against any job description to find missing keywords.',
      icon: Target,
      actionLabel: 'Check ATS Match',
    },
    {
      id: 'interview' as AppView,
      title: 'Interview Preparation',
      description: 'Generate technical & HR questions from your resume and practice answers.',
      icon: Mic,
      actionLabel: 'Start Practice',
    },
  ];

  const templateLabel = (t: ResumeData['template']) => {
    if (t === 'executive-blue') return 'Executive Blue';
    if (t === 'classic-academic') return 'Classic Academic';
    return 'Minimalist Slate';
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Welcome & Focal CTA */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div className="max-w-2xl space-y-2">
          <p className="text-xs font-medium text-blue-600 dark:text-blue-400">
            Smart Career Workspace
          </p>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white text-balance">
            Build ATS-ready resumes and prepare for interviews with confidence
          </h1>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            Designed for students, freshers, and professionals. Generate structured resumes, audit PDF drafts, match job descriptions, and practice real interview questions.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onCreateNew}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
          >
            <FilePlus2 className="w-4 h-4" />
            Create New Resume
          </button>
          <button
            type="button"
            onClick={() => onNavigate('analyzer')}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
          >
            <FileSearch className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            Analyze My Resume
          </button>
        </div>
      </section>

      {/* Core Career Tools Grid */}
      <section className="space-y-4">
        <div className="flex items-baseline justify-between">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
            Career Toolkit
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            5 integrated AI tools
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickTools.map((tool) => {
            const Icon = tool.icon;
            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => onNavigate(tool.id)}
                className="group text-left bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-500 rounded-xl p-5 flex flex-col justify-between gap-4 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
              >
                <div className="space-y-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {tool.title}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {tool.description}
                    </p>
                  </div>
                </div>
                <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400">
                  {tool.actionLabel}
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Recently Created Resumes */}
      <section className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
              Recently Created Resumes
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Saved locally in your browser for instant editing, PDF export, and ATS checks
            </p>
          </div>
          {resumes.length > 0 && (
            <button
              type="button"
              onClick={onCreateNew}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
            >
              + New Resume
            </button>
          )}
        </div>

        {resumes.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center space-y-4">
            <div className="w-12 h-12 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 mx-auto flex items-center justify-center">
              <FileText className="w-6 h-6" />
            </div>
            <div className="space-y-1 max-w-md mx-auto">
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                No saved resumes yet
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Create your first resume with AI assistance or load our sample fresher profile to explore templates and PDF export.
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={onCreateNew}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors cursor-pointer"
              >
                <FilePlus2 className="w-4 h-4" />
                Create First Resume
              </button>
              <button
                type="button"
                onClick={() => onNavigate('chatbot')}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 text-sm font-medium transition-colors cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                Ask Career Assistant
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800">
            {resumes.map((resume) => (
              <div
                key={resume.id}
                className="p-4 sm:p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
              >
                <div className="space-y-1 min-w-0">
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                    {resume.title || resume.personal.fullName}
                  </h3>
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
                    <span>{resume.targetRole || 'General Role'}</span>
                    <span aria-hidden="true">·</span>
                    <span>{resume.experienceLevel}</span>
                    <span aria-hidden="true">·</span>
                    <span>{templateLabel(resume.template)}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">Updated {formatShortDate(resume.updatedAt)}</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => onEditResume(resume)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => onDownloadPdf(resume)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-xs font-medium text-white transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Download className="w-3.5 h-3.5" />
                    PDF
                  </button>
                  <button
                    type="button"
                    onClick={() => onSendToAts(resume)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Target className="w-3.5 h-3.5" />
                    ATS Check
                  </button>
                  <button
                    type="button"
                    onClick={() => onSendToInterview(resume)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Mic className="w-3.5 h-3.5" />
                    Interview
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteResume(resume.id)}
                    aria-label={`Delete ${resume.title || resume.personal.fullName}`}
                    className="inline-flex items-center justify-center p-1.5 rounded-lg text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
