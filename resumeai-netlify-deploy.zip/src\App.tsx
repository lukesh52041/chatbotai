/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { MotionConfig, motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard,
  FilePlus2,
  FileSearch,
  MessageSquare,
  Target,
  Mic,
  Sun,
  Moon,
  Menu,
  X,
  Briefcase,
  KeyRound,
  Check,
  Sparkles,
} from 'lucide-react';
import { AppView, ChatMessage, ResumeData } from './types';
import {
  STORAGE_CHAT_KEY,
  STORAGE_RESUMES_KEY,
  STORAGE_THEME_KEY,
  exportResumeToPdf,
  getCustomApiKey,
  setCustomApiKey,
} from './utils/resumeHelpers';
import { DashboardView } from './components/DashboardView';
import { ResumeBuilderView } from './components/ResumeBuilderView';
import { ResumeAnalyzerView } from './components/ResumeAnalyzerView';
import { ChatbotView } from './components/ChatbotView';
import { AtsCheckerView } from './components/AtsCheckerView';
import { InterviewPrepView } from './components/InterviewPrepView';

interface NavItem {
  id: AppView;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'builder', label: 'AI Resume Builder', icon: FilePlus2 },
  { id: 'analyzer', label: 'Resume Analyzer', icon: FileSearch },
  { id: 'chatbot', label: 'AI Career Chatbot', icon: MessageSquare },
  { id: 'ats', label: 'ATS Score Checker', icon: Target },
  { id: 'interview', label: 'Interview Prep', icon: Mic },
];

interface ApiSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

function ApiSettingsModal({ isOpen, onClose }: ApiSettingsModalProps) {
  const [apiKeyInput, setApiKeyInput] = useState(() => getCustomApiKey());
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [serverHealth, setServerHealth] = useState<{
    ok?: boolean;
    hasServerKey?: boolean;
    chatModel?: string;
    fastModel?: string;
    platform?: string;
  } | null>(null);
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setChecking(true);
    fetch('/api/health')
      .then((r) => r.json())
      .then((data) => setServerHealth(data))
      .catch(() => setServerHealth({ ok: false }))
      .finally(() => setChecking(false));
  }, [isOpen]);

  const handleSave = () => {
    setCustomApiKey(apiKeyInput);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 800);
  };

  const handleClear = () => {
    setApiKeyInput('');
    setCustomApiKey('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">API & Netlify Settings</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Gemini AI connection status</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close settings"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Server Status Badge */}
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-medium text-slate-600 dark:text-slate-300">Netlify Server:</span>
            {checking ? (
              <span className="text-slate-400">Checking...</span>
            ) : serverHealth?.ok ? (
              <span className="inline-flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Connected ({serverHealth.platform || 'Netlify Function'})
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-amber-500 font-semibold">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                Function Offline / Static
              </span>
            )}
          </div>
          <div className="flex items-center justify-between">
            <span className="font-medium text-slate-600 dark:text-slate-300">Server GEMINI_API_KEY:</span>
            <span className={serverHealth?.hasServerKey ? "text-emerald-600 dark:text-emerald-400 font-semibold" : "text-amber-500 font-medium"}>
              {serverHealth?.hasServerKey ? 'Detected in Netlify Env' : 'Not set in Netlify Env'}
            </span>
          </div>
        </div>

        {/* Custom API Key input */}
        <div className="space-y-1.5">
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Custom Gemini API Key (Client Override)
          </label>
          <input
            type="password"
            value={apiKeyInput}
            onChange={(e) => setApiKeyInput(e.target.value)}
            placeholder="AIzaSy..."
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
            If you have configured <code>GEMINI_API_KEY</code> in Netlify Environment Variables, leave this empty. Or enter your key to test on mobile immediately.
          </p>
        </div>

        <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 text-xs text-blue-900 dark:text-blue-200 space-y-1">
          <p className="font-semibold flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            Netlify Production Setup:
          </p>
          <p className="text-[11px] leading-relaxed text-blue-800 dark:text-blue-300">
            Netlify Dashboard → <strong>Site configuration</strong> → <strong>Environment variables</strong> → Add <code>GEMINI_API_KEY</code>.
          </p>
        </div>

        <div className="flex items-center justify-end gap-2.5 pt-1">
          {apiKeyInput && (
            <button
              type="button"
              onClick={handleClear}
              className="px-3 py-2 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              Clear Key
            </button>
          )}
          <button
            type="button"
            onClick={handleSave}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-sm transition-colors cursor-pointer"
          >
            {savedSuccess ? (
              <>
                <Check className="w-3.5 h-3.5" />
                Saved!
              </>
            ) : (
              'Save Key'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [activeView, setActiveView] = useState<AppView>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_THEME_KEY);
      if (saved === 'dark') return true;
      if (saved === 'light') return false;
      return window.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false;
    } catch {
      return false;
    }
  });

  const [resumes, setResumes] = useState<ResumeData[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_RESUMES_KEY);
      return raw ? (JSON.parse(raw) as ResumeData[]) : [];
    } catch {
      return [];
    }
  });

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_CHAT_KEY);
      return raw ? (JSON.parse(raw) as ChatMessage[]) : [];
    } catch {
      return [];
    }
  });

  const [editingResume, setEditingResume] = useState<ResumeData | null>(null);
  const [preselectedAtsId, setPreselectedAtsId] = useState<string | null>(null);
  const [preselectedInterviewId, setPreselectedInterviewId] = useState<string | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(STORAGE_THEME_KEY, darkMode ? 'dark' : 'light');
    } catch {
      // Ignore storage quota errors
    }
  }, [darkMode]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_RESUMES_KEY, JSON.stringify(resumes));
    } catch {
      // Ignore storage quota errors
    }
  }, [resumes]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CHAT_KEY, JSON.stringify(chatMessages));
    } catch {
      // Ignore storage quota errors
    }
  }, [chatMessages]);

  const navigateTo = (view: AppView) => {
    setActiveView(view);
    setMobileMenuOpen(false);
  };

  const handleCreateNewResume = () => {
    setEditingResume(null);
    navigateTo('builder');
  };

  const handleEditResume = (resume: ResumeData) => {
    setEditingResume(resume);
    navigateTo('builder');
  };

  const handleSaveResume = (saved: ResumeData) => {
    setResumes((prev) => {
      const exists = prev.some((r) => r.id === saved.id);
      if (exists) {
        return prev.map((r) => (r.id === saved.id ? saved : r));
      }
      return [saved, ...prev];
    });
    setEditingResume(saved);
  };

  const handleDeleteResume = (id: string) => {
    setResumes((prev) => prev.filter((r) => r.id !== id));
    if (editingResume?.id === id) {
      setEditingResume(null);
    }
  };

  const handleSendToAts = (resume: ResumeData) => {
    setPreselectedAtsId(resume.id);
    navigateTo('ats');
  };

  const handleSendToInterview = (resume: ResumeData) => {
    setPreselectedInterviewId(resume.id);
    navigateTo('interview');
  };

  const activeNavLabel =
    NAV_ITEMS.find((n) => n.id === activeView)?.label ?? 'Dashboard';

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen flex bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:shrink-0 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <div className="h-16 px-6 flex items-center gap-2.5 border-b border-slate-200 dark:border-slate-800">
            <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
              <Briefcase className="w-4 h-4" />
            </div>
            <span className="text-base font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
              ResumeAI
            </span>
          </div>

          <nav aria-label="Primary Navigation" className="flex-1 px-3 py-5 space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigateTo(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 font-semibold'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="p-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-1">
              <span>Saved Resumes</span>
              <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-white">
                {resumes.length}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setSettingsOpen(true)}
              className="w-full flex items-center justify-between px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <KeyRound className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                API & Netlify
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
            </button>
            <button
              type="button"
              onClick={() => setDarkMode((prev) => !prev)}
              className="w-full flex items-center justify-between px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <span>{darkMode ? 'Dark Mode' : 'Light Mode'}</span>
              {darkMode ? <Moon className="w-4 h-4 text-blue-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
            </button>
          </div>
        </aside>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-slate-950/50"
              onClick={() => setMobileMenuOpen(false)}
              aria-hidden="true"
            />
            <aside className="relative z-10 w-72 max-w-[85vw] bg-white dark:bg-slate-900 h-full border-r border-slate-200 dark:border-slate-800 flex flex-col">
              <div className="h-16 px-5 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center">
                    <Briefcase className="w-4 h-4" />
                  </div>
                  <span className="text-base font-bold text-slate-900 dark:text-white">
                    ResumeAI
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  aria-label="Close navigation menu"
                  className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <nav className="flex-1 px-3 py-4 space-y-1">
                {NAV_ITEMS.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeView === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => navigateTo(item.id)}
                      className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                        isActive
                          ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 font-semibold'
                          : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </nav>

              <div className="p-4 border-t border-slate-200 dark:border-slate-800 space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setSettingsOpen(true);
                  }}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <KeyRound className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                    API & Netlify Settings
                  </span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                </button>
                <button
                  type="button"
                  onClick={() => setDarkMode((prev) => !prev)}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  <span>{darkMode ? 'Dark Mode' : 'Light Mode'}</span>
                  {darkMode ? <Moon className="w-4 h-4 text-blue-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
                </button>
              </div>
            </aside>
          </div>
        )}

        {/* Main Workspace */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Top Header */}
          <header className="h-16 px-4 sm:px-6 lg:px-8 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between gap-4 shrink-0">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                aria-label="Open navigation menu"
                className="lg:hidden p-2 -ml-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2 text-sm min-w-0">
                <span className="text-slate-400 dark:text-slate-500 hidden sm:inline">
                  ResumeAI
                </span>
                <span className="text-slate-300 dark:text-slate-700 hidden sm:inline" aria-hidden="true">
                  /
                </span>
                <span className="font-semibold text-slate-900 dark:text-white truncate">
                  {activeNavLabel}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setSettingsOpen(true)}
                title="API & Netlify Settings"
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <KeyRound className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              </button>
              <button
                type="button"
                onClick={() => setDarkMode((prev) => !prev)}
                aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
                className="lg:hidden p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 cursor-pointer"
              >
                {darkMode ? <Moon className="w-4 h-4 text-blue-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
              </button>
              <button
                type="button"
                onClick={handleCreateNewResume}
                className="inline-flex items-center gap-1.5 px-3 py-2 sm:px-3.5 sm:py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <FilePlus2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">New Resume</span>
                <span className="sm:hidden">New</span>
              </button>
            </div>
          </header>

          {/* Main Viewport */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto pb-24 lg:pb-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeView}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
              >
                {activeView === 'dashboard' && (
                  <DashboardView
                    resumes={resumes}
                    onNavigate={navigateTo}
                    onCreateNew={handleCreateNewResume}
                    onEditResume={handleEditResume}
                    onDeleteResume={handleDeleteResume}
                    onDownloadPdf={exportResumeToPdf}
                    onSendToAts={handleSendToAts}
                    onSendToInterview={handleSendToInterview}
                  />
                )}

                {activeView === 'builder' && (
                  <ResumeBuilderView
                    initialResume={editingResume}
                    onSaveResume={handleSaveResume}
                  />
                )}

                {activeView === 'analyzer' && <ResumeAnalyzerView resumes={resumes} />}

                {activeView === 'chatbot' && (
                  <ChatbotView
                    messages={chatMessages}
                    onUpdateMessages={setChatMessages}
                    onClearHistory={() => setChatMessages([])}
                    resumes={resumes}
                  />
                )}

                {activeView === 'ats' && (
                  <AtsCheckerView
                    resumes={resumes}
                    preselectedResumeId={preselectedAtsId}
                  />
                )}

                {activeView === 'interview' && (
                  <InterviewPrepView
                    resumes={resumes}
                    preselectedResumeId={preselectedInterviewId}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </main>

          {/* Mobile Bottom Navigation Bar */}
          <nav
            aria-label="Mobile Navigation"
            className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 safe-area-pb shadow-[0_-4px_12px_rgba(0,0,0,0.05)]"
          >
            <div className="grid grid-cols-6 h-16 items-center px-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                const shortLabel =
                  item.id === 'dashboard'
                    ? 'Home'
                    : item.id === 'builder'
                    ? 'Builder'
                    : item.id === 'analyzer'
                    ? 'Audit'
                    : item.id === 'chatbot'
                    ? 'Chat'
                    : item.id === 'ats'
                    ? 'ATS'
                    : 'Interview';

                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => navigateTo(item.id)}
                    className={`flex flex-col items-center justify-center h-full py-1 gap-1 transition-colors relative cursor-pointer ${
                      isActive
                        ? 'text-blue-600 dark:text-blue-400 font-semibold'
                        : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
                    <span className="text-[10px] leading-tight truncate max-w-full px-0.5">
                      {shortLabel}
                    </span>
                    {item.id === 'builder' && resumes.length > 0 && (
                      <span className="absolute top-2 right-2 sm:right-3 w-2 h-2 rounded-full bg-blue-600" />
                    )}
                  </button>
                );
              })}
            </div>
          </nav>
        </div>
      </div>

      <ApiSettingsModal isOpen={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </MotionConfig>
  );
}
