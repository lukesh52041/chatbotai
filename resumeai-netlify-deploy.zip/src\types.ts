export type ExperienceLevel = 'Student' | 'Fresher' | 'Experienced';
export type ResumeTemplateId = 'executive-blue' | 'classic-academic' | 'minimalist-slate';
export type AppView = 'dashboard' | 'builder' | 'analyzer' | 'chatbot' | 'ats' | 'interview';

export interface EducationItem {
  id: string;
  degree: string;
  institution: string;
  duration: string;
  grade: string;
  highlights: string;
}

export interface ProjectItem {
  id: string;
  title: string;
  techStack: string;
  link: string;
  bullets: string[];
}

export interface InternshipItem {
  id: string;
  role: string;
  company: string;
  duration: string;
  location: string;
  bullets: string[];
}

export interface ResumeData {
  id: string;
  title: string;
  template: ResumeTemplateId;
  updatedAt: string;
  experienceLevel: ExperienceLevel;
  targetRole: string;
  personal: {
    fullName: string;
    email: string;
    phone: string;
    location: string;
    linkedin: string;
    portfolio: string;
  };
  summary: string;
  careerObjective?: string;
  education: EducationItem[];
  skills: {
    technical: string[];
    tools: string[];
    soft: string[];
  };
  projects: ProjectItem[];
  internships: InternshipItem[];
  certifications: string[];
  achievements: string[];
}

export interface ResumeBuilderInput {
  fullName: string;
  email: string;
  phone: string;
  location: string;
  linkedin: string;
  portfolio: string;
  targetRole: string;
  experienceLevel: ExperienceLevel;
  careerObjectiveInput: string;
  educationRaw: string;
  skillsRaw: string;
  projectsRaw: string;
  internshipsRaw: string;
  certificationsRaw: string;
  achievementsRaw: string;
  customInstruction?: string;
}

export interface ResumeAnalysisResult {
  overallScore: number;
  sectionScores: {
    impact: number;
    clarity: number;
    formatting: number;
    skillsRelevance: number;
    grammar: number;
  };
  summaryVerdict: string;
  strengths: string[];
  missingSkills: string[];
  grammarIssues: Array<{
    original: string;
    correction: string;
    reason: string;
  }>;
  weakDescriptions: Array<{
    section: string;
    current: string;
    improved: string;
    explanation: string;
  }>;
  formattingIssues: string[];
  actionableTips: string[];
}

export interface AtsCheckResult {
  atsScore: number;
  keywordMatchRate: number;
  verdict: string;
  matchedKeywords: string[];
  missingKeywords: string[];
  headingAudit: Array<{
    heading: string;
    status: 'pass' | 'warn' | 'fail';
    recommendation: string;
  }>;
  formattingChecks: Array<{
    check: string;
    passed: boolean;
    detail: string;
  }>;
  tailoringSuggestions: string[];
}

export interface InterviewQuestion {
  id: string;
  category: 'Technical' | 'HR';
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  question: string;
  whyAsked: string;
  keyPoints: string[];
  sampleAnswer: string;
  tips: string;
}

export interface InterviewPrepResult {
  roleFocus: string;
  overviewTips: string[];
  questions: InterviewQuestion[];
}

export interface AnswerEvaluationResult {
  score: number;
  verdict: string;
  strengths: string[];
  improvements: string[];
  refinedAnswer: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}
