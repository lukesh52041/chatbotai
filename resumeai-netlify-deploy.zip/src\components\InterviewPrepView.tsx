import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Loader2,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Send,
  Upload,
  FileText,
  X,
  CheckCircle2,
} from 'lucide-react';
import {
  AnswerEvaluationResult,
  ExperienceLevel,
  InterviewPrepResult,
  ResumeData,
} from '../types';
import { fileToBase64, getApiHeaders, serializeResumeToText } from '../utils/resumeHelpers';

interface InterviewPrepViewProps {
  resumes: ResumeData[];
  preselectedResumeId: string | null;
}

export const InterviewPrepView: React.FC<InterviewPrepViewProps> = ({
  resumes,
  preselectedResumeId,
}) => {
  const [sourceMode, setSourceMode] = useState<'saved' | 'pdf' | 'role'>(
    preselectedResumeId || resumes.length > 0 ? 'saved' : 'role'
  );
  const [selectedSavedId, setSelectedSavedId] = useState<string>(
    preselectedResumeId ?? resumes[0]?.id ?? ''
  );
  const [selectedFile, setSelectedFile] = useState<{ name: string; base64: string } | null>(null);
  const [targetRole, setTargetRole] = useState('Junior Full-Stack Software Engineer');
  const [experienceLevel, setExperienceLevel] = useState<ExperienceLevel>('Fresher');
  const [focus, setFocus] = useState<'mixed' | 'technical' | 'hr'>('mixed');
  const [categoryFilter, setCategoryFilter] = useState<'All' | 'Technical' | 'HR'>('All');

  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [prepKit, setPrepKit] = useState<InterviewPrepResult | null>(null);

  const [expandedAnswerIds, setExpandedAnswerIds] = useState<Record<string, boolean>>({});
  const [practiceDrafts, setPracticeDrafts] = useState<Record<string, string>>({});
  const [evaluatingId, setEvaluatingId] = useState<string | null>(null);
  const [evaluations, setEvaluations] = useState<Record<string, AnswerEvaluationResult>>({});
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (preselectedResumeId) {
      setSourceMode('saved');
      setSelectedSavedId(preselectedResumeId);
      const found = resumes.find((r) => r.id === preselectedResumeId);
      if (found) {
        if (found.targetRole) setTargetRole(found.targetRole);
        setExperienceLevel(found.experienceLevel);
      }
    }
  }, [preselectedResumeId, resumes]);

  const handleFileChange = async (file: File | undefined) => {
    if (!file) return;
    setError(null);
    if (file.type !== 'application/pdf') {
      setError('Please upload a valid PDF file (.pdf).');
      return;
    }
    try {
      const base64 = await fileToBase64(file);
      setSelectedFile({ name: file.name, base64 });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to read PDF file.');
    }
  };

  const handleGenerateQuestions = async () => {
    setError(null);
    const payload: {
      pdfBase64?: string;
      resumeText?: string;
      targetRole: string;
      experienceLevel: string;
      focus: 'mixed' | 'technical' | 'hr';
    } = {
      targetRole: targetRole.trim() || 'Entry-Level Professional',
      experienceLevel,
      focus,
    };

    if (sourceMode === 'saved') {
      const found = resumes.find((r) => r.id === selectedSavedId);
      if (!found) {
        setError('Please select a saved resume or switch to Role Only.');
        return;
      }
      payload.resumeText = serializeResumeToText(found);
      if (!targetRole.trim() && found.targetRole) {
        payload.targetRole = found.targetRole;
      }
    } else if (sourceMode === 'pdf') {
      if (!selectedFile) {
        setError('Please upload a PDF resume.');
        return;
      }
      payload.pdfBase64 = selectedFile.base64;
    }

    setIsGenerating(true);
    setEvaluations({});
    setPracticeDrafts({});
    try {
      const response = await fetch('/api/interview/generate', {
        method: 'POST',
        headers: getApiHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(payload),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate interview questions.');
      }
      setPrepKit(data.prepKit);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to generate interview prep.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleEvaluatePractice = async (questionId: string, questionText: string) => {
    const draft = (practiceDrafts[questionId] ?? '').trim();
    if (!draft) {
      setError('Write your practice answer first before requesting AI feedback.');
      return;
    }
    setError(null);
    setEvaluatingId(questionId);
    try {
      const response = await fetch('/api/interview/evaluate', {
        method: 'POST',
        headers: getApiHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          question: questionText,
          userAnswer: draft,
          targetRole,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Evaluation failed.');
      }
      setEvaluations((prev) => ({ ...prev, [questionId]: data.evaluation }));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not evaluate answer.');
    } finally {
      setEvaluatingId(null);
    }
  };

  const filteredQuestions =
    prepKit?.questions.filter((q) =>
      categoryFilter === 'All' ? true : q.category === categoryFilter
    ) ?? [];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Configuration Card */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Interview Preparation & Practice Coach
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Generate tailored technical and HR questions from your resume, study sample answers, and practice with live AI feedback.
            </p>
          </div>
          <div className="inline-flex items-center p-1 rounded-lg bg-slate-100 dark:bg-slate-800 shrink-0">
            <button
              type="button"
              onClick={() => setSourceMode('saved')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer whitespace-nowrap ${
                sourceMode === 'saved'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Saved Resume
            </button>
            <button
              type="button"
              onClick={() => setSourceMode('pdf')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer whitespace-nowrap ${
                sourceMode === 'pdf'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Upload PDF
            </button>
            <button
              type="button"
              onClick={() => setSourceMode('role')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer whitespace-nowrap ${
                sourceMode === 'role'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              By Role Only
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {sourceMode === 'saved' && (
            <div className="md:col-span-3">
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Select Resume
              </label>
              {resumes.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  No saved resumes yet. Switch to Upload PDF or By Role Only.
                </p>
              ) : (
                <select
                  value={selectedSavedId}
                  onChange={(e) => setSelectedSavedId(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                >
                  {resumes.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.title || r.personal.fullName}
                    </option>
                  ))}
                </select>
              )}
            </div>
          )}

          {sourceMode === 'pdf' && (
            <div className="md:col-span-3">
              <input
                ref={fileInputRef}
                type="file"
                accept="application/pdf"
                onChange={(e) => handleFileChange(e.target.files?.[0])}
                className="hidden"
              />
              {selectedFile ? (
                <div className="inline-flex items-center gap-2.5 px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <span className="text-slate-900 dark:text-white">{selectedFile.name}</span>
                  <button
                    type="button"
                    onClick={() => setSelectedFile(null)}
                    className="text-slate-400 hover:text-red-500 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-blue-600" />
                  Upload PDF Resume
                </button>
              )}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Target Job Role
            </label>
            <input
              type="text"
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
              placeholder="e.g. Junior Software Engineer"
              className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Experience Level
            </label>
            <select
              value={experienceLevel}
              onChange={(e) => setExperienceLevel(e.target.value as ExperienceLevel)}
              className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
            >
              <option value="Student">Student / Intern</option>
              <option value="Fresher">Fresher (0-1 yrs)</option>
              <option value="Experienced">Experienced</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Interview Focus
            </label>
            <select
              value={focus}
              onChange={(e) => setFocus(e.target.value as 'mixed' | 'technical' | 'hr')}
              className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
            >
              <option value="mixed">Technical + HR Mix</option>
              <option value="technical">Technical & Projects Only</option>
              <option value="hr">HR & Behavioral Only</option>
            </select>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="button"
            disabled={isGenerating}
            onClick={handleGenerateQuestions}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold transition-colors cursor-pointer"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Preparing Questions...
              </>
            ) : (
              <>
                <Mic className="w-4 h-4" />
                Generate Interview Questions
              </>
            )}
          </button>
        </div>

        {error && (
          <div
            role="alert"
            className="flex items-start gap-2.5 p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm"
          >
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </section>

      {isGenerating && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4 animate-pulse">
          <div className="h-5 w-48 bg-slate-200 dark:bg-slate-800 rounded" />
          <div className="h-28 bg-slate-100 dark:bg-slate-800/70 rounded-lg" />
          <div className="h-28 bg-slate-100 dark:bg-slate-800/70 rounded-lg" />
        </div>
      )}

      {prepKit && !isGenerating && (
        <div className="space-y-5">
          {/* Overview Tips & Filter Bar */}
          <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="space-y-1">
              <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                Prep Kit: {prepKit.roleFocus}
              </h2>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                {prepKit.overviewTips.join(' · ')}
              </p>
            </div>

            <div className="inline-flex items-center p-1 rounded-lg bg-slate-100 dark:bg-slate-800 shrink-0 self-start">
              {(['All', 'Technical', 'HR'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setCategoryFilter(tab)}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer whitespace-nowrap ${
                    categoryFilter === tab
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </section>

          {/* Question Cards */}
          <div className="space-y-4">
            {filteredQuestions.map((q, index) => {
              const isOpen = !!expandedAnswerIds[q.id];
              const evalResult = evaluations[q.id];
              const isEvaluating = evaluatingId === q.id;

              return (
                <article
                  key={q.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 space-y-4"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-mono tabular-nums font-semibold text-blue-600 dark:text-blue-400">
                        Q{index + 1}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-medium text-slate-700 dark:text-slate-300">
                        {q.category}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{q.difficulty}</span>
                    </div>
                    <h3 className="text-base font-semibold text-slate-900 dark:text-white leading-snug">
                      {q.question}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">Why interviewers ask this: </span>
                      {q.whyAsked}
                    </p>
                  </div>

                  {/* Practice Answer Input */}
                  <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Practice Your Answer
                    </label>
                    <textarea
                      rows={3}
                      value={practiceDrafts[q.id] ?? ''}
                      onChange={(e) =>
                        setPracticeDrafts((prev) => ({ ...prev, [q.id]: e.target.value }))
                      }
                      placeholder="Type how you would answer this question out loud..."
                      className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedAnswerIds((prev) => ({ ...prev, [q.id]: !isOpen }))
                        }
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                      >
                        {isOpen ? (
                          <>
                            <ChevronUp className="w-4 h-4" /> Hide Sample Answer & Tips
                          </>
                        ) : (
                          <>
                            <ChevronDown className="w-4 h-4" /> View Sample Answer & Tips
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        disabled={isEvaluating}
                        onClick={() => handleEvaluatePractice(q.id, q.question)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-xs font-semibold transition-colors cursor-pointer"
                      >
                        {isEvaluating ? (
                          <>
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            Evaluating...
                          </>
                        ) : (
                          <>
                            <Send className="w-3.5 h-3.5" />
                            Get AI Feedback
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* AI Evaluation Result */}
                  {evalResult && (
                    <div className="p-4 rounded-xl bg-blue-50/50 dark:bg-blue-950/25 border border-blue-200 dark:border-blue-900/60 space-y-3">
                      <div className="flex flex-wrap items-baseline justify-between gap-2">
                        <span className="text-xs font-semibold text-blue-700 dark:text-blue-400">
                          AI Practice Feedback
                        </span>
                        <span className="text-sm font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                          Score: {evalResult.score}/100
                        </span>
                      </div>
                      <p className="text-sm text-slate-700 dark:text-slate-200">
                        {evalResult.verdict}
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div>
                          <p className="font-semibold text-emerald-700 dark:text-emerald-400 mb-1">
                            What Worked Well
                          </p>
                          <ul className="list-disc pl-4 space-y-1 text-slate-700 dark:text-slate-300">
                            {evalResult.strengths.map((s, i) => (
                              <li key={i}>{s}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <p className="font-semibold text-amber-700 dark:text-amber-400 mb-1">
                            How to Improve
                          </p>
                          <ul className="list-disc pl-4 space-y-1 text-slate-700 dark:text-slate-300">
                            {evalResult.improvements.map((imp, i) => (
                              <li key={i}>{imp}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                      <div className="pt-2 border-t border-blue-200/60 dark:border-blue-900/50">
                        <p className="text-xs font-semibold text-slate-900 dark:text-white mb-1">
                          Polished Version of Your Answer
                        </p>
                        <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                          {evalResult.refinedAnswer}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Sample Answer & Key Points */}
                  {isOpen && (
                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3">
                      <div>
                        <p className="text-xs font-semibold text-slate-900 dark:text-white mb-1.5">
                          Key Points to Hit
                        </p>
                        <ul className="space-y-1 text-xs text-slate-700 dark:text-slate-300">
                          {q.keyPoints.map((pt, i) => (
                            <li key={i} className="flex items-start gap-2">
                              <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 mt-0.5 shrink-0" />
                              <span>{pt}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-slate-900 dark:text-white mb-1">
                          Sample Answer
                        </p>
                        <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                          {q.sampleAnswer}
                        </p>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">Delivery Tip: </span>
                        {q.tips}
                      </p>
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
