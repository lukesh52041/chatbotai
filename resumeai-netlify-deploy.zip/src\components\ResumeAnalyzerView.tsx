import React, { useState, useRef } from 'react';
import {
  Upload,
  FileText,
  Loader2,
  AlertCircle,
  CheckCircle2,
  AlertTriangle,
  Copy,
  Check,
  Sparkles,
  X,
} from 'lucide-react';
import { ResumeAnalysisResult, ResumeData } from '../types';
import { fileToBase64, getApiHeaders, serializeResumeToText } from '../utils/resumeHelpers';

interface ResumeAnalyzerViewProps {
  resumes: ResumeData[];
}

export const ResumeAnalyzerView: React.FC<ResumeAnalyzerViewProps> = ({ resumes }) => {
  const [sourceMode, setSourceMode] = useState<'pdf' | 'saved' | 'text'>('pdf');
  const [selectedFile, setSelectedFile] = useState<{ name: string; base64: string } | null>(null);
  const [selectedSavedId, setSelectedSavedId] = useState<string>(resumes[0]?.id ?? '');
  const [pastedText, setPastedText] = useState('');
  const [targetRole, setTargetRole] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ResumeAnalysisResult | null>(null);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = async (file: File | undefined) => {
    if (!file) return;
    setError(null);
    if (file.type !== 'application/pdf') {
      setError('Please upload a valid PDF file (.pdf).');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('PDF file size must be under 10 MB.');
      return;
    }
    try {
      const base64 = await fileToBase64(file);
      setSelectedFile({ name: file.name, base64 });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to read PDF file.');
    }
  };

  const handleAnalyze = async () => {
    setError(null);
    const payload: { pdfBase64?: string; resumeText?: string; targetRole?: string } = {
      targetRole: targetRole.trim() || undefined,
    };

    if (sourceMode === 'pdf') {
      if (!selectedFile) {
        setError('Please upload a PDF resume first.');
        return;
      }
      payload.pdfBase64 = selectedFile.base64;
    } else if (sourceMode === 'saved') {
      const found = resumes.find((r) => r.id === selectedSavedId);
      if (!found) {
        setError('Please select a saved resume or switch to PDF upload.');
        return;
      }
      payload.resumeText = serializeResumeToText(found);
    } else {
      if (!pastedText.trim()) {
        setError('Please paste your resume text to analyze.');
        return;
      }
      payload.resumeText = pastedText.trim();
    }

    setIsAnalyzing(true);
    try {
      const response = await fetch('/api/resume/analyze', {
        method: 'POST',
        headers: getApiHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(payload),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Resume analysis failed.');
      }
      setResult(data.analysis);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to analyze resume.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleCopyRewrite = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 1800);
  };

  const scoreTone = (score: number) => {
    if (score >= 80) return 'text-emerald-600 dark:text-emerald-400';
    if (score >= 60) return 'text-amber-600 dark:text-amber-400';
    return 'text-red-600 dark:text-red-400';
  };

  const barTone = (score: number) => {
    if (score >= 80) return 'bg-emerald-600';
    if (score >= 60) return 'bg-amber-500';
    return 'bg-red-600';
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Input Card */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              AI Resume Analyzer
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Upload your PDF resume for an instant score out of 100, grammar audit, missing skills check, and stronger bullet rewrites.
            </p>
          </div>

          <div className="inline-flex items-center p-1 rounded-lg bg-slate-100 dark:bg-slate-800 shrink-0">
            <button
              type="button"
              onClick={() => setSourceMode('pdf')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                sourceMode === 'pdf'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Upload PDF
            </button>
            <button
              type="button"
              onClick={() => setSourceMode('saved')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                sourceMode === 'saved'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Saved Resume
            </button>
            <button
              type="button"
              onClick={() => setSourceMode('text')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                sourceMode === 'text'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Paste Text
            </button>
          </div>
        </div>

        {sourceMode === 'pdf' && (
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              handleFileChange(e.dataTransfer.files[0]);
            }}
            className="border border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-6 text-center bg-slate-50/60 dark:bg-slate-950/40"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="application/pdf"
              onChange={(e) => handleFileChange(e.target.files?.[0])}
              className="hidden"
            />
            {selectedFile ? (
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <div className="inline-flex items-center gap-2 text-sm font-medium text-slate-900 dark:text-white">
                  <FileText className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  <span>{selectedFile.name}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedFile(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                  className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 hover:text-red-600 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" /> Remove
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                <div className="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 mx-auto flex items-center justify-center">
                  <Upload className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
                    Drag and drop your PDF resume here
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    PDF format up to 10 MB · Parsed directly with Gemini multimodal AI
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  Browse PDF File
                </button>
              </div>
            )}
          </div>
        )}

        {sourceMode === 'saved' && (
          <div>
            {resumes.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400 py-3">
                You don't have any saved resumes yet. Create one in the AI Resume Builder or upload a PDF.
              </p>
            ) : (
              <select
                value={selectedSavedId}
                onChange={(e) => setSelectedSavedId(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              >
                {resumes.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.title || r.personal.fullName} ({r.targetRole || r.experienceLevel})
                  </option>
                ))}
              </select>
            )}
          </div>
        )}

        {sourceMode === 'text' && (
          <textarea
            rows={6}
            value={pastedText}
            onChange={(e) => setPastedText(e.target.value)}
            placeholder="Paste the full text of your resume here..."
            className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        )}

        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-end">
          <div className="flex-1">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Target Role (Optional — improves skill gap detection)
            </label>
            <input
              type="text"
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
              placeholder="e.g. Frontend Developer, Data Analyst, Product Intern"
              className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            type="button"
            disabled={isAnalyzing}
            onClick={handleAnalyze}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Analyzing Resume...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Analyze Resume
              </>
            )}
          </button>
        </div>

        {error && (
          <div
            role="alert"
            className="flex items-start gap-2.5 p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm"
          >
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </section>

      {/* Loading Skeleton */}
      {isAnalyzing && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4 animate-pulse">
          <div className="h-6 w-48 bg-slate-200 dark:bg-slate-800 rounded" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="h-28 bg-slate-100 dark:bg-slate-800/70 rounded-lg" />
            <div className="h-28 bg-slate-100 dark:bg-slate-800/70 rounded-lg md:col-span-2" />
          </div>
        </div>
      )}

      {/* Results View */}
      {result && !isAnalyzing && (
        <div className="space-y-6">
          {/* Score Overview */}
          <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-4 flex items-center gap-5">
              <div className="w-24 h-24 rounded-full border-4 border-blue-600/20 dark:border-blue-500/30 flex flex-col items-center justify-center shrink-0">
                <span className={`text-3xl font-bold font-mono tabular-nums ${scoreTone(result.overallScore)}`}>
                  {result.overallScore}
                </span>
                <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                  out of 100
                </span>
              </div>
              <div className="space-y-1">
                <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                  Overall Resume Score
                </h2>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {result.summaryVerdict}
                </p>
              </div>
            </div>

            <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 pt-4 lg:pt-0 border-t lg:border-t-0 lg:border-l border-slate-200 dark:border-slate-800 lg:pl-6">
              {[
                { label: 'Impact', val: result.sectionScores.impact },
                { label: 'Clarity', val: result.sectionScores.clarity },
                { label: 'Formatting', val: result.sectionScores.formatting },
                { label: 'Skills Fit', val: result.sectionScores.skillsRelevance },
                { label: 'Grammar', val: result.sectionScores.grammar },
              ].map((metric) => (
                <div key={metric.label} className="space-y-1.5">
                  <div className="flex items-baseline justify-between text-xs">
                    <span className="font-medium text-slate-600 dark:text-slate-400">{metric.label}</span>
                    <span className="font-mono font-semibold tabular-nums text-slate-900 dark:text-white">
                      {metric.val}
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${barTone(metric.val)}`}
                      style={{ width: `${Math.min(100, Math.max(0, metric.val))}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Strengths & Missing Skills */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                Key Strengths
              </h3>
              <ul className="space-y-2 text-sm text-slate-700 dark:text-slate-300 list-disc pl-5">
                {result.strengths.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </section>

            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                Missing Skills & Keywords
              </h3>
              {result.missingSkills.length === 0 ? (
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  No major skill gaps detected for this target profile.
                </p>
              ) : (
                <ul className="space-y-2 text-sm text-slate-700 dark:text-slate-300 list-disc pl-5">
                  {result.missingSkills.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ul>
              )}
            </section>
          </div>

          {/* Weak Descriptions & Rewrites */}
          {result.weakDescriptions.length > 0 && (
            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                  Bullet Point Improvements
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Stronger, action-driven rewrites for weak or vague descriptions found in your resume.
                </p>
              </div>
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {result.weakDescriptions.map((item, idx) => (
                  <div key={idx} className="py-4 first:pt-0 last:pb-0 space-y-2.5">
                    <div className="text-xs font-semibold text-blue-600 dark:text-blue-400">
                      {item.section}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                        <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                          Current Phrasing
                        </p>
                        <p className="text-sm text-slate-700 dark:text-slate-300">{item.current}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-blue-50/50 dark:bg-blue-950/25 border border-blue-200 dark:border-blue-900/60">
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <p className="text-[11px] font-semibold text-blue-700 dark:text-blue-400">
                            Suggested Rewrite
                          </p>
                          <button
                            type="button"
                            onClick={() => handleCopyRewrite(item.improved, idx)}
                            className="inline-flex items-center gap-1 text-[11px] font-medium text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                          >
                            {copiedIdx === idx ? (
                              <>
                                <Check className="w-3 h-3" /> Copied
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" /> Copy
                              </>
                            )}
                          </button>
                        </div>
                        <p className="text-sm text-slate-900 dark:text-slate-100 font-medium">
                          {item.improved}
                        </p>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">{item.explanation}</p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Grammar & Formatting + Action Plan */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                Grammar & Formatting Audit
              </h3>

              {result.grammarIssues.length > 0 && (
                <div className="space-y-2.5">
                  <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                    Grammar & Clarity Fixes
                  </p>
                  <div className="space-y-2">
                    {result.grammarIssues.map((g, i) => (
                      <div
                        key={i}
                        className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs space-y-1"
                      >
                        <p className="text-red-600 dark:text-red-400 line-through">{g.original}</p>
                        <p className="text-emerald-700 dark:text-emerald-400 font-medium">{g.correction}</p>
                        <p className="text-slate-500 dark:text-slate-400">{g.reason}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {result.formattingIssues.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                    Formatting Observations
                  </p>
                  <ul className="space-y-1.5 text-sm text-slate-700 dark:text-slate-300 list-disc pl-5">
                    {result.formattingIssues.map((f, i) => (
                      <li key={i}>{f}</li>
                    ))}
                  </ul>
                </div>
              )}
            </section>

            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                Prioritized Action Plan
              </h3>
              <ol className="space-y-2.5 text-sm text-slate-700 dark:text-slate-300 list-decimal pl-5">
                {result.actionableTips.map((tip, i) => (
                  <li key={i} className="leading-relaxed">
                    {tip}
                  </li>
                ))}
              </ol>
            </section>
          </div>
        </div>
      )}
    </div>
  );
};
