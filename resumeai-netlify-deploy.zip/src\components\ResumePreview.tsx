import React from 'react';
import { Mail, Phone, MapPin, Linkedin, Globe } from 'lucide-react';
import { ResumeData } from '../types';

interface ResumePreviewProps {
  resume: ResumeData;
}

export const ResumePreview: React.FC<ResumePreviewProps> = ({ resume }) => {
  const { template, personal, targetRole, summary, careerObjective, education, skills, projects, internships, certifications, achievements } = resume;

  const isExecutive = template === 'executive-blue';
  const isClassic = template === 'classic-academic';
  const isMinimal = template === 'minimalist-slate';

  const hasSkills =
    skills.technical.length > 0 || skills.tools.length > 0 || skills.soft.length > 0;

  return (
    <div
      className={`bg-white text-slate-900 shadow-sm border border-slate-200 rounded-md mx-auto w-full max-w-[794px] min-h-[960px] overflow-hidden ${
        isClassic ? 'font-serif' : 'font-sans'
      }`}
    >
      {/* Header Band */}
      <div
        className={
          isExecutive
            ? 'bg-slate-50 border-b-2 border-blue-600 px-5 sm:px-8 py-5 sm:py-7'
            : isClassic
            ? 'border-b border-slate-300 px-5 sm:px-8 pt-6 sm:pt-8 pb-5 text-center'
            : 'border-b border-slate-200 px-5 sm:px-8 pt-6 sm:pt-8 pb-5'
        }
      >
        <h1
          className={`font-bold tracking-tight text-slate-900 ${
            isClassic ? 'text-2xl' : 'text-[26px]'
          }`}
        >
          {personal.fullName || 'Your Name'}
        </h1>
        {targetRole && (
          <p
            className={`mt-1 text-sm font-semibold ${
              isExecutive ? 'text-blue-700' : 'text-slate-600'
            }`}
          >
            {targetRole}
          </p>
        )}

        <div
          className={`mt-3 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-slate-600 ${
            isClassic ? 'justify-center' : 'justify-start'
          }`}
        >
          {personal.email && (
            <span className="inline-flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-slate-400" />
              {personal.email}
            </span>
          )}
          {personal.phone && (
            <span className="inline-flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              {personal.phone}
            </span>
          )}
          {personal.location && (
            <span className="inline-flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              {personal.location}
            </span>
          )}
          {personal.linkedin && (
            <span className="inline-flex items-center gap-1.5">
              <Linkedin className="w-3.5 h-3.5 text-slate-400" />
              {personal.linkedin}
            </span>
          )}
          {personal.portfolio && (
            <span className="inline-flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-slate-400" />
              {personal.portfolio}
            </span>
          )}
        </div>
      </div>

      {/* Body Sections */}
      <div className="px-5 sm:px-8 py-5 sm:py-6 space-y-5 text-[13px] leading-relaxed text-slate-700">
        {summary && (
          <section>
            <h2
              className={`text-xs font-bold tracking-wider uppercase pb-1 mb-2 border-b ${
                isExecutive
                  ? 'text-blue-700 border-blue-200'
                  : isMinimal
                  ? 'text-slate-900 border-slate-200'
                  : 'text-slate-800 border-slate-300'
              }`}
            >
              Professional Summary
            </h2>
            <p className="text-slate-700">{summary}</p>
          </section>
        )}

        {careerObjective && (
          <section>
            <h2
              className={`text-xs font-bold tracking-wider uppercase pb-1 mb-2 border-b ${
                isExecutive
                  ? 'text-blue-700 border-blue-200'
                  : isMinimal
                  ? 'text-slate-900 border-slate-200'
                  : 'text-slate-800 border-slate-300'
              }`}
            >
              Career Objective
            </h2>
            <p className="text-slate-700">{careerObjective}</p>
          </section>
        )}

        {education.length > 0 && (
          <section>
            <h2
              className={`text-xs font-bold tracking-wider uppercase pb-1 mb-2.5 border-b ${
                isExecutive
                  ? 'text-blue-700 border-blue-200'
                  : isMinimal
                  ? 'text-slate-900 border-slate-200'
                  : 'text-slate-800 border-slate-300'
              }`}
            >
              Education
            </h2>
            <div className="space-y-2.5">
              {education.map((edu) => (
                <div key={edu.id}>
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <span className="font-semibold text-slate-900">{edu.degree}</span>
                    <span className="text-xs text-slate-500 tabular-nums">{edu.duration}</span>
                  </div>
                  <div className="flex flex-wrap items-baseline justify-between gap-2 text-slate-600">
                    <span className="italic">{edu.institution}</span>
                    {edu.grade && <span className="text-xs font-medium text-slate-700">{edu.grade}</span>}
                  </div>
                  {edu.highlights && (
                    <p className="mt-1 text-xs text-slate-600">{edu.highlights}</p>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {hasSkills && (
          <section>
            <h2
              className={`text-xs font-bold tracking-wider uppercase pb-1 mb-2 border-b ${
                isExecutive
                  ? 'text-blue-700 border-blue-200'
                  : isMinimal
                  ? 'text-slate-900 border-slate-200'
                  : 'text-slate-800 border-slate-300'
              }`}
            >
              Skills
            </h2>
            <div className="space-y-1.5 text-[12.5px]">
              {skills.technical.length > 0 && (
                <div>
                  <span className="font-semibold text-slate-900">Technical: </span>
                  <span>{skills.technical.join(', ')}</span>
                </div>
              )}
              {skills.tools.length > 0 && (
                <div>
                  <span className="font-semibold text-slate-900">Tools & Platforms: </span>
                  <span>{skills.tools.join(', ')}</span>
                </div>
              )}
              {skills.soft.length > 0 && (
                <div>
                  <span className="font-semibold text-slate-900">Interpersonal: </span>
                  <span>{skills.soft.join(', ')}</span>
                </div>
              )}
            </div>
          </section>
        )}

        {internships.length > 0 && (
          <section>
            <h2
              className={`text-xs font-bold tracking-wider uppercase pb-1 mb-2.5 border-b ${
                isExecutive
                  ? 'text-blue-700 border-blue-200'
                  : isMinimal
                  ? 'text-slate-900 border-slate-200'
                  : 'text-slate-800 border-slate-300'
              }`}
            >
              Experience & Internships
            </h2>
            <div className="space-y-3">
              {internships.map((intern) => (
                <div key={intern.id}>
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <span className="font-semibold text-slate-900">
                      {intern.role} <span className="font-normal text-slate-600">· {intern.company}</span>
                    </span>
                    <span className="text-xs text-slate-500 tabular-nums">{intern.duration}</span>
                  </div>
                  {intern.location && (
                    <p className="text-xs italic text-slate-500">{intern.location}</p>
                  )}
                  <ul className="mt-1.5 list-disc pl-4 space-y-1 text-slate-700">
                    {intern.bullets.filter(Boolean).map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        )}

        {projects.length > 0 && (
          <section>
            <h2
              className={`text-xs font-bold tracking-wider uppercase pb-1 mb-2.5 border-b ${
                isExecutive
                  ? 'text-blue-700 border-blue-200'
                  : isMinimal
                  ? 'text-slate-900 border-slate-200'
                  : 'text-slate-800 border-slate-300'
              }`}
            >
              Projects
            </h2>
            <div className="space-y-3">
              {projects.map((proj) => (
                <div key={proj.id}>
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <span className="font-semibold text-slate-900">{proj.title}</span>
                    {proj.techStack && (
                      <span
                        className={`text-xs font-medium ${
                          isExecutive ? 'text-blue-700' : 'text-slate-500'
                        }`}
                      >
                        {proj.techStack}
                      </span>
                    )}
                  </div>
                  {proj.link && <p className="text-xs text-slate-500">{proj.link}</p>}
                  <ul className="mt-1.5 list-disc pl-4 space-y-1 text-slate-700">
                    {proj.bullets.filter(Boolean).map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        )}

        {certifications.length > 0 && (
          <section>
            <h2
              className={`text-xs font-bold tracking-wider uppercase pb-1 mb-2 border-b ${
                isExecutive
                  ? 'text-blue-700 border-blue-200'
                  : isMinimal
                  ? 'text-slate-900 border-slate-200'
                  : 'text-slate-800 border-slate-300'
              }`}
            >
              Certifications
            </h2>
            <ul className="list-disc pl-4 space-y-1">
              {certifications.filter(Boolean).map((cert, i) => (
                <li key={i}>{cert}</li>
              ))}
            </ul>
          </section>
        )}

        {achievements.length > 0 && (
          <section>
            <h2
              className={`text-xs font-bold tracking-wider uppercase pb-1 mb-2 border-b ${
                isExecutive
                  ? 'text-blue-700 border-blue-200'
                  : isMinimal
                  ? 'text-slate-900 border-slate-200'
                  : 'text-slate-800 border-slate-300'
              }`}
            >
              Achievements
            </h2>
            <ul className="list-disc pl-4 space-y-1">
              {achievements.filter(Boolean).map((ach, i) => (
                <li key={i}>{ach}</li>
              ))}
            </ul>
          </section>
        )}
      </div>
    </div>
  );
};
