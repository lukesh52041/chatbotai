# ResumeAI – Your Smart Career Assistant

An AI-powered mobile-first career assistant built with React 19, TypeScript, Tailwind CSS, and Google Gemini AI.

---

## Features
- **AI Resume Builder:** Generate and polish structured, ATS-ready resumes with 3 professional templates and 1-click PDF download.
- **Resume Analyzer:** Upload PDF resumes or paste text for a comprehensive audit (score, grammar check, and bullet rewrites).
- **ATS Keyword Matcher:** Compare your resume against any job description to identify missing keywords and formatting improvements.
- **AI Interview Coach:** Generate realistic Technical & HR interview questions tailored to your profile, practice your answers, and receive instant AI feedback.
- **Career Assistant Chatbot:** Live interactive chat for resume tips, LinkedIn optimization, and career guidance.
- **Mobile-First Experience:** Persistent mobile bottom navigation, iOS zoom prevention, touch targets >= 44px, notch safe-area handling, and Progressive Web App (PWA) manifest ("Add to Home Screen").

---

## Deploying to Netlify

This project is configured out of the box for Netlify deployment using `netlify.toml` and Netlify Serverless Functions (`netlify/functions/api.ts`).

### Method 1: Git-Based Deployment (Recommended)

1. **Push your code to GitHub, GitLab, or Bitbucket**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit for ResumeAI"
   git remote add origin https://github.com/your-username/resume-ai.git
   git push -u origin main
   ```

2. **Connect to Netlify**:
   - Go to [app.netlify.com](https://app.netlify.com) and log in.
   - Click **Add new site** → **Import an existing project**.
   - Select your Git provider and choose the `resume-ai` repository.

3. **Verify Build Settings** (automatically read from `netlify.toml`):
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
   - **Functions directory:** `netlify/functions`

4. **Add Your Gemini API Key**:
   - In Netlify, go to **Site configuration** → **Environment variables**.
   - Click **Add a variable** → **Add a single variable**.
   - Key: `GEMINI_API_KEY`
   - Value: *Your Google Gemini API Key* (obtain free from [Google AI Studio](https://aistudio.google.com/app/apikey))
   - Click **Create variable**.

5. **Deploy**:
   - Click **Deploy site** (or trigger a new deploy if already connected).
   - Your site will be live at `https://your-site-name.netlify.app`.

---

### Method 2: Deploy with Netlify CLI

1. Build the app locally:
   ```bash
   npm install
   npm run build
   ```

2. Deploy using Netlify CLI:
   ```bash
   npx netlify deploy --prod
   ```

3. Set your environment variable:
   ```bash
   npx netlify env:set GEMINI_API_KEY "your_gemini_api_key"
   ```

---

### Mobile Web Installation (PWA)
Once deployed on Netlify, open your URL on any mobile device:
- **iPhone / iOS Safari:** Tap the **Share** button → Tap **Add to Home Screen**.
- **Android Chrome:** Tap the **Menu (three dots)** → Tap **Add to Home screen** / **Install app**.

The app opens fullscreen just like a native mobile app with bottom navigation.

---

## Local Development

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Set your GEMINI_API_KEY in .env

# 3. Start local development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser. Use Chrome DevTools Device Mode (Ctrl+Shift+M or Cmd+Shift+M) to test mobile screen viewports.
