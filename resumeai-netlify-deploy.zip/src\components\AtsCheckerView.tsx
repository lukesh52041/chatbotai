import React, { useState, useRef, useEffect } from 'react';
import {
  Target,
  Upload,
  FileText,
  Loader2,
  AlertCircle,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  X,
} from 'lucide-react';
import { AtsCheckResult, ResumeData } from '../types';
import {
  fileToBase64,
  getApiHeaders,
  SAMPLE_JOB_DESCRIPTION,
  serializeResumeToText,
} from '../utils/resumeHelpers';

interface AtsCheckerViewProps {
  resumes: ResumeData[];
  preselectedResumeId: string | null;
}

export const AtsCheckerView: React.FC<AtsCheckerViewProps> = ({
  resumes,
  preselectedResumeId,
}) => {
  const [sourceMode, setSourceMode] = useState<'saved' | 'pdf' | 'text'>(
    preselectedResumeId || resumes.length > 0 ? 'saved' : 'pdf'
  );
  const [selectedSavedId, setSelectedSavedId] = useState<string>(
    preselectedResumeId ?? resumes[0]?.id ?? ''
  );
  const [selectedFile, setSelectedFile] = useState<{ name: string; base64: string } | null>(null);
  const [pastedText, setPastedText] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AtsCheckResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (preselectedResumeId) {
      setSourceMode('saved');
      setSelectedSavedId(preselectedResumeId);
    }
  }, [preselectedResumeId]);

  const handleFileChange = async (file: File | undefined) => {
    if (!file) return;
    setError(null);
    if (file.type !== 'application/pdf') {
      setError('Please upload a valid PDF file (.pdf).');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('PDF file size must be under 10 MB.');
      return;
    }
    try {
      const base64 = await fileToBase64(file);
      setSelectedFile({ name: file.name, base64 });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to read PDF file.');
    }
  };

  const handleRunAtsCheck = async () => {
    setError(null);
    if (!jobDescription.trim()) {
      setError('Please paste the target job description to run the ATS comparison.');
      return;
    }

    const payload: { pdfBase64?: string; resumeText?: string; jobDescription: string } = {
      jobDescription: jobDescription.trim(),
    };

    if (sourceMode === 'pdf') {
      if (!selectedFile) {
        setError('Please upload a PDF resume.');
        return;
      }
      payload.pdfBase64 = selectedFile.base64;
    } else if (sourceMode === 'saved') {
      const found = resumes.find((r) => r.id === selectedSavedId);
      if (!found) {
        setError('Please select a saved resume or upload a PDF.');
        return;
      }
      payload.resumeText = serializeResumeToText(found);
    } else {
      if (!pastedText.trim()) {
        setError('Please paste your resume text.');
        return;
      }
      payload.resumeText = pastedText.trim();
    }

    setIsChecking(true);
    try {
      const response = await fetch('/api/ats/check', {
        method: 'POST',
        headers: getApiHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(payload),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'ATS check failed.');
      }
      setResult(data.atsResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to complete ATS check.');
    } finally {
      setIsChecking(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              ATS Resume Checker
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Audit ATS compatibility, heading structure, and keyword match against any target job description.
            </p>
          </div>
          <div className="inline-flex items-center p-1 rounded-lg bg-slate-100 dark:bg-slate-800 shrink-0">
            <button
              type="button"
              onClick={() => setSourceMode('saved')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer whitespace-nowrap ${
                sourceMode === 'saved'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Saved Resume
            </button>
            <button
              type="button"
              onClick={() => setSourceMode('pdf')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer whitespace-nowrap ${
                sourceMode === 'pdf'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Upload PDF
            </button>
            <button
              type="button"
              onClick={() => setSourceMode('text')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer whitespace-nowrap ${
                sourceMode === 'text'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Paste Text
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Left: Resume Source */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              1. Your Resume
            </label>

            {sourceMode === 'saved' && (
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/50 space-y-2">
                {resumes.length === 0 ? (
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    No saved resumes yet. Switch to Upload PDF or Paste Text, or create a resume in Builder.
                  </p>
                ) : (
                  <select
                    value={selectedSavedId}
                    onChange={(e) => setSelectedSavedId(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                  >
                    {resumes.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.title || r.personal.fullName}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            )}

            {sourceMode === 'pdf' && (
              <div className="border border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-5 text-center bg-slate-50/60 dark:bg-slate-950/40">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="application/pdf"
                  onChange={(e) => handleFileChange(e.target.files?.[0])}
                  className="hidden"
                />
                {selectedFile ? (
                  <div className="flex items-center justify-center gap-3 text-sm">
                    <FileText className="w-4 h-4 text-blue-600" />
                    <span className="font-medium text-slate-900 dark:text-white truncate max-w-[220px]">
                      {selectedFile.name}
                    </span>
                    <button
                      type="button"
                      onClick={() => setSelectedFile(null)}
                      className="text-slate-400 hover:text-red-500 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
                  >
                    <Upload className="w-4 h-4 text-blue-600" />
                    Select PDF Resume
                  </button>
                )}
              </div>
            )}

            {sourceMode === 'text' && (
              <textarea
                rows={7}
                value={pastedText}
                onChange={(e) => setPastedText(e.target.value)}
                placeholder="Paste your resume content..."
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            )}
          </div>

          {/* Right: Target Job Description */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                2. Target Job Description
              </label>
              <button
                type="button"
                onClick={() => setJobDescription(SAMPLE_JOB_DESCRIPTION)}
                className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
              >
                Use Sample Job Description
              </button>
            </div>
            <textarea
              rows={7}
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              placeholder="Paste the job description (requirements, responsibilities, skills) here..."
              className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="button"
            disabled={isChecking}
            onClick={handleRunAtsCheck}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold transition-colors cursor-pointer"
          >
            {isChecking ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Checking ATS Compatibility...
              </>
            ) : (
              <>
                <Target className="w-4 h-4" />
                Check ATS Score
              </>
            )}
          </button>
        </div>

        {error && (
          <div
            role="alert"
            className="flex items-start gap-2.5 p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm"
          >
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </section>

      {isChecking && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4 animate-pulse">
          <div className="h-6 w-56 bg-slate-200 dark:bg-slate-800 rounded" />
          <div className="h-24 bg-slate-100 dark:bg-slate-800/70 rounded-lg" />
        </div>
      )}

      {result && !isChecking && (
        <div className="space-y-6">
          {/* Score Summary Row */}
          <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            <div className="md:col-span-3 space-y-1">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                ATS Compatibility Score
              </p>
              <p className="text-4xl font-bold font-mono tabular-nums text-blue-600 dark:text-blue-400">
                {result.atsScore}
                <span className="text-lg font-normal text-slate-400">/100</span>
              </p>
            </div>
            <div className="md:col-span-3 space-y-1 md:border-l border-slate-200 dark:border-slate-800 md:pl-6">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                JD Keyword Match
              </p>
              <p className="text-4xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                {result.keywordMatchRate}%
              </p>
            </div>
            <div className="md:col-span-6 md:border-l border-slate-200 dark:border-slate-800 md:pl-6">
              <p className="text-xs font-semibold text-slate-900 dark:text-white mb-1">
                Parser Verdict
              </p>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {result.verdict}
              </p>
            </div>
          </section>

          {/* Keyword Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                Matched Keywords ({result.matchedKeywords.length})
              </h3>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                {result.matchedKeywords.length > 0
                  ? result.matchedKeywords.join(' · ')
                  : 'No direct keyword matches found.'}
              </p>
            </section>

            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                Missing Keywords ({result.missingKeywords.length})
              </h3>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                {result.missingKeywords.length > 0
                  ? result.missingKeywords.join(' · ')
                  : 'All major JD keywords are present in your resume.'}
              </p>
            </section>
          </div>

          {/* Headings & Formatting Audit */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                Section Headings Audit
              </h3>
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {result.headingAudit.map((h, i) => (
                  <div key={i} className="py-3 first:pt-0 last:pb-0 flex items-start justify-between gap-4">
                    <div className="space-y-0.5">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">
                        {h.heading}
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        {h.recommendation}
                      </p>
                    </div>
                    <span
                      className={`inline-flex items-center gap-1 text-xs font-semibold shrink-0 ${
                        h.status === 'pass'
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : h.status === 'warn'
                          ? 'text-amber-600 dark:text-amber-400'
                          : 'text-red-600 dark:text-red-400'
                      }`}
                    >
                      {h.status === 'pass' && <CheckCircle2 className="w-3.5 h-3.5" />}
                      {h.status === 'warn' && <AlertTriangle className="w-3.5 h-3.5" />}
                      {h.status === 'fail' && <XCircle className="w-3.5 h-3.5" />}
                      {h.status === 'pass' ? 'Pass' : h.status === 'warn' ? 'Improve' : 'Missing'}
                    </span>
                  </div>
                ))}
              </div>
            </section>

            <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                ATS Parsing & Formatting Checks
              </h3>
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {result.formattingChecks.map((chk, i) => (
                  <div key={i} className="py-3 first:pt-0 last:pb-0 flex items-start justify-between gap-4">
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium text-slate-900 dark:text-white">
                        {chk.check}
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-400">{chk.detail}</p>
                    </div>
                    <span
                      className={`inline-flex items-center gap-1 text-xs font-semibold shrink-0 ${
                        chk.passed
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-red-600 dark:text-red-400'
                      }`}
                    >
                      {chk.passed ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" /> Passed
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3.5 h-3.5" /> Fix Needed
                        </>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Tailoring Suggestions */}
          <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
            <h3 className="text-base font-semibold text-slate-900 dark:text-white">
              Tailoring Recommendations
            </h3>
            <ol className="list-decimal pl-5 space-y-2 text-sm text-slate-700 dark:text-slate-300">
              {result.tailoringSuggestions.map((tip, i) => (
                <li key={i} className="leading-relaxed">
                  {tip}
                </li>
              ))}
            </ol>
          </section>
        </div>
      )}
    </div>
  );
};
