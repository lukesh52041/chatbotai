import { jsPDF } from 'jspdf';
import { ResumeBuilderInput, ResumeData } from '../types';

export const STORAGE_RESUMES_KEY = 'resumeai_saved_resumes_v1';
export const STORAGE_CHAT_KEY = 'resumeai_chat_history_v1';
export const STORAGE_THEME_KEY = 'resumeai_theme_v1';
export const STORAGE_API_KEY = 'resumeai_custom_gemini_api_key_v1';

export function getCustomApiKey(): string {
  try {
    return localStorage.getItem(STORAGE_API_KEY) || '';
  } catch {
    return '';
  }
}

export function setCustomApiKey(key: string): void {
  try {
    if (key && key.trim()) {
      localStorage.setItem(STORAGE_API_KEY, key.trim());
    } else {
      localStorage.removeItem(STORAGE_API_KEY);
    }
  } catch {
    // Ignore storage quota errors
  }
}

export function getApiHeaders(extraHeaders: Record<string, string> = {}): Record<string, string> {
  const headers: Record<string, string> = { ...extraHeaders };
  const customKey = getCustomApiKey();
  if (customKey) {
    headers['x-gemini-api-key'] = customKey;
  }
  return headers;
}

export function generateId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function formatShortDate(isoString: string): string {
  try {
    return new Date(isoString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  } catch {
    return isoString;
  }
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to read file as base64.'));
      }
    };
    reader.onerror = () => reject(new Error('Error reading selected file.'));
    reader.readAsDataURL(file);
  });
}

export function serializeResumeToText(resume: ResumeData): string {
  const lines: string[] = [];
  lines.push(resume.personal.fullName);
  const contacts = [
    resume.personal.email,
    resume.personal.phone,
    resume.personal.location,
    resume.personal.linkedin,
    resume.personal.portfolio,
  ].filter(Boolean);
  if (contacts.length) lines.push(contacts.join(' | '));
  if (resume.targetRole) lines.push(`Target Role: ${resume.targetRole}`);
  lines.push('');

  if (resume.summary) {
    lines.push('PROFESSIONAL SUMMARY');
    lines.push(resume.summary);
    lines.push('');
  }

  if (resume.careerObjective) {
    lines.push('CAREER OBJECTIVE');
    lines.push(resume.careerObjective);
    lines.push('');
  }

  if (resume.education.length) {
    lines.push('EDUCATION');
    resume.education.forEach((edu) => {
      lines.push(`${edu.degree} — ${edu.institution} (${edu.duration})${edu.grade ? ` | ${edu.grade}` : ''}`);
      if (edu.highlights) lines.push(`  ${edu.highlights}`);
    });
    lines.push('');
  }

  const allSkills = [
    resume.skills.technical.length ? `Technical: ${resume.skills.technical.join(', ')}` : '',
    resume.skills.tools.length ? `Tools: ${resume.skills.tools.join(', ')}` : '',
    resume.skills.soft.length ? `Soft Skills: ${resume.skills.soft.join(', ')}` : '',
  ].filter(Boolean);
  if (allSkills.length) {
    lines.push('SKILLS');
    lines.push(...allSkills);
    lines.push('');
  }

  if (resume.internships.length) {
    lines.push('EXPERIENCE & INTERNSHIPS');
    resume.internships.forEach((intern) => {
      lines.push(`${intern.role} — ${intern.company} (${intern.duration})${intern.location ? ` | ${intern.location}` : ''}`);
      intern.bullets.forEach((b) => lines.push(`- ${b}`));
    });
    lines.push('');
  }

  if (resume.projects.length) {
    lines.push('PROJECTS');
    resume.projects.forEach((proj) => {
      lines.push(`${proj.title}${proj.techStack ? ` | ${proj.techStack}` : ''}${proj.link ? ` | ${proj.link}` : ''}`);
      proj.bullets.forEach((b) => lines.push(`- ${b}`));
    });
    lines.push('');
  }

  if (resume.certifications.length) {
    lines.push('CERTIFICATIONS');
    resume.certifications.forEach((c) => lines.push(`- ${c}`));
    lines.push('');
  }

  if (resume.achievements.length) {
    lines.push('ACHIEVEMENTS');
    resume.achievements.forEach((a) => lines.push(`- ${a}`));
  }

  return lines.join('\n');
}

export function exportResumeToPdf(resume: ResumeData): void {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 44;
  const maxWidth = pageWidth - margin * 2;
  let y = margin;

  const isClassic = resume.template === 'classic-academic';
  const isExecutive = resume.template === 'executive-blue';
  const fontBody = isClassic ? 'times' : 'helvetica';
  const accentRgb: [number, number, number] = isExecutive
    ? [37, 99, 235]
    : isClassic
    ? [30, 41, 59]
    : [15, 23, 42];

  const ensureSpace = (needed: number) => {
    if (y + needed > pageHeight - margin) {
      doc.addPage();
      y = margin;
    }
  };

  const drawWrapped = (text: string, x: number, width: number, fontSize: number, style: 'normal' | 'bold' | 'italic' = 'normal', color: [number, number, number] = [30, 41, 59], lineHeight = 1.38) => {
    doc.setFont(fontBody, style);
    doc.setFontSize(fontSize);
    doc.setTextColor(...color);
    const lines: string[] = doc.splitTextToSize(text, width);
    const step = fontSize * lineHeight;
    for (const line of lines) {
      ensureSpace(step);
      doc.text(line, x, y);
      y += step;
    }
  };

  const drawSectionHeading = (title: string) => {
    ensureSpace(28);
    y += 8;
    doc.setFont(fontBody, 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(...accentRgb);
    doc.text(title.toUpperCase(), margin, y);
    y += 5;
    const dividerRgb: [number, number, number] = isExecutive ? accentRgb : [203, 213, 225];
    doc.setDrawColor(dividerRgb[0], dividerRgb[1], dividerRgb[2]);
    doc.setLineWidth(isExecutive ? 1.1 : 0.7);
    doc.line(margin, y, pageWidth - margin, y);
    y += 13;
  };

  // Header
  if (isExecutive) {
    doc.setFillColor(248, 250, 252);
    doc.rect(0, 0, pageWidth, 96, 'F');
    doc.setDrawColor(37, 99, 235);
    doc.setLineWidth(2);
    doc.line(0, 96, pageWidth, 96);
    y = 38;
  }

  doc.setFont(fontBody, 'bold');
  doc.setFontSize(20);
  doc.setTextColor(15, 23, 42);
  doc.text(resume.personal.fullName || 'Untitled Resume', margin, y);
  y += 16;

  if (resume.targetRole) {
    doc.setFont(fontBody, 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(...accentRgb);
    doc.text(resume.targetRole, margin, y);
    y += 14;
  }

  const contactParts = [
    resume.personal.email,
    resume.personal.phone,
    resume.personal.location,
    resume.personal.linkedin,
    resume.personal.portfolio,
  ].filter(Boolean);

  if (contactParts.length > 0) {
    drawWrapped(contactParts.join('  •  '), margin, maxWidth, 9, 'normal', [71, 85, 105], 1.3);
  }

  if (isExecutive && y < 110) {
    y = 114;
  } else {
    y += 4;
  }

  // Summary & Career Objective
  if (resume.summary.trim()) {
    drawSectionHeading('Professional Summary');
    drawWrapped(resume.summary.trim(), margin, maxWidth, 9.8, 'normal', [51, 65, 85]);
  }
  if (resume.careerObjective?.trim()) {
    drawSectionHeading('Career Objective');
    drawWrapped(resume.careerObjective.trim(), margin, maxWidth, 9.8, 'normal', [51, 65, 85]);
  }

  // Education
  if (resume.education.length > 0) {
    drawSectionHeading('Education');
    for (const edu of resume.education) {
      ensureSpace(34);
      doc.setFont(fontBody, 'bold');
      doc.setFontSize(10.2);
      doc.setTextColor(15, 23, 42);
      doc.text(edu.degree, margin, y);
      if (edu.duration) {
        doc.setFont(fontBody, 'normal');
        doc.setFontSize(9.2);
        doc.setTextColor(100, 116, 139);
        doc.text(edu.duration, pageWidth - margin, y, { align: 'right' });
      }
      y += 13;

      const subLine = [edu.institution, edu.grade].filter(Boolean).join('  •  ');
      if (subLine) {
        drawWrapped(subLine, margin, maxWidth, 9.5, 'italic', [71, 85, 105]);
      }
      if (edu.highlights) {
        drawWrapped(edu.highlights, margin + 8, maxWidth - 8, 9.2, 'normal', [71, 85, 105]);
      }
      y += 4;
    }
  }

  // Skills
  const hasSkills =
    resume.skills.technical.length > 0 ||
    resume.skills.tools.length > 0 ||
    resume.skills.soft.length > 0;
  if (hasSkills) {
    drawSectionHeading('Skills');
    if (resume.skills.technical.length > 0) {
      drawWrapped(`Technical Skills: ${resume.skills.technical.join(', ')}`, margin, maxWidth, 9.5, 'normal', [30, 41, 59]);
    }
    if (resume.skills.tools.length > 0) {
      drawWrapped(`Tools & Platforms: ${resume.skills.tools.join(', ')}`, margin, maxWidth, 9.5, 'normal', [30, 41, 59]);
    }
    if (resume.skills.soft.length > 0) {
      drawWrapped(`Interpersonal: ${resume.skills.soft.join(', ')}`, margin, maxWidth, 9.5, 'normal', [30, 41, 59]);
    }
  }

  // Internships / Experience
  if (resume.internships.length > 0) {
    drawSectionHeading('Experience & Internships');
    for (const item of resume.internships) {
      ensureSpace(36);
      doc.setFont(fontBody, 'bold');
      doc.setFontSize(10.2);
      doc.setTextColor(15, 23, 42);
      doc.text(`${item.role} — ${item.company}`, margin, y);
      if (item.duration) {
        doc.setFont(fontBody, 'normal');
        doc.setFontSize(9.2);
        doc.setTextColor(100, 116, 139);
        doc.text(item.duration, pageWidth - margin, y, { align: 'right' });
      }
      y += 13;
      if (item.location) {
        drawWrapped(item.location, margin, maxWidth, 9, 'italic', [100, 116, 139]);
      }
      for (const bullet of item.bullets) {
        if (!bullet.trim()) continue;
        drawWrapped(`•  ${bullet.trim()}`, margin + 8, maxWidth - 8, 9.5, 'normal', [51, 65, 85]);
      }
      y += 4;
    }
  }

  // Projects
  if (resume.projects.length > 0) {
    drawSectionHeading('Projects');
    for (const proj of resume.projects) {
      ensureSpace(34);
      doc.setFont(fontBody, 'bold');
      doc.setFontSize(10.2);
      doc.setTextColor(15, 23, 42);
      doc.text(proj.title, margin, y);
      if (proj.techStack) {
        doc.setFont(fontBody, 'normal');
        doc.setFontSize(9);
        doc.setTextColor(...accentRgb);
        doc.text(proj.techStack, pageWidth - margin, y, { align: 'right' });
      }
      y += 13;
      if (proj.link) {
        drawWrapped(proj.link, margin, maxWidth, 8.8, 'normal', [100, 116, 139]);
      }
      for (const bullet of proj.bullets) {
        if (!bullet.trim()) continue;
        drawWrapped(`•  ${bullet.trim()}`, margin + 8, maxWidth - 8, 9.5, 'normal', [51, 65, 85]);
      }
      y += 4;
    }
  }

  // Certifications
  if (resume.certifications.length > 0) {
    drawSectionHeading('Certifications');
    for (const cert of resume.certifications) {
      if (!cert.trim()) continue;
      drawWrapped(`•  ${cert.trim()}`, margin + 8, maxWidth - 8, 9.5, 'normal', [51, 65, 85]);
    }
  }

  // Achievements
  if (resume.achievements.length > 0) {
    drawSectionHeading('Achievements');
    for (const ach of resume.achievements) {
      if (!ach.trim()) continue;
      drawWrapped(`•  ${ach.trim()}`, margin + 8, maxWidth - 8, 9.5, 'normal', [51, 65, 85]);
    }
  }

  const safeName = (resume.personal.fullName || 'Resume').replace(/[^a-z0-9]+/gi, '_');
  doc.save(`${safeName}_ResumeAI.pdf`);
}

export const SAMPLE_BUILDER_INPUT: ResumeBuilderInput = {
  fullName: 'Aarav Sharma',
  email: 'aarav.sharma@example.com',
  phone: '+91 98765 43210',
  location: 'Bengaluru, India',
  linkedin: 'linkedin.com/in/aaravsharma',
  portfolio: 'github.com/aaravsharma',
  targetRole: 'Junior Full-Stack Software Engineer',
  experienceLevel: 'Fresher',
  careerObjectiveInput:
    'Computer Science final-year student looking for an entry-level software engineering role to build scalable web applications and learn from experienced engineering teams.',
  educationRaw:
    'B.Tech in Computer Science & Engineering, BMS College of Engineering (2022 - 2026), CGPA: 8.8/10. Relevant coursework: Data Structures, DBMS, Operating Systems, Web Development.',
  skillsRaw:
    'JavaScript, TypeScript, React, Node.js, Express, Python, SQL, PostgreSQL, Git, Docker, Tailwind CSS, Problem Solving, Team Collaboration',
  projectsRaw:
    '1. CampusConnect Event Portal (React, Node.js, PostgreSQL) - Built a college club event registration platform used by 600+ students with QR check-in.\n2. SmartExpense Tracker (TypeScript, Chart.js) - Created a personal budget tracker with CSV import and automated monthly category alerts.',
  internshipsRaw:
    'Frontend Developer Intern at FinFlow Labs (May 2025 - Jul 2025, Remote) - Built reusable React dashboard tables, fixed 15+ UI responsiveness bugs, and improved page load speed by 25%.',
  certificationsRaw:
    'Meta Front-End Developer Professional Certificate (Coursera)\nAWS Cloud Practitioner Essentials',
  achievementsRaw:
    'Finalist in Smart India Hackathon 2025 among 120+ teams\nSolved 350+ algorithmic coding problems on LeetCode',
};

export const SAMPLE_JOB_DESCRIPTION = `Junior Full-Stack Software Engineer
We are seeking an enthusiastic Junior Full-Stack Engineer to join our product engineering team.

Responsibilities:
- Build responsive web interfaces using React, TypeScript, and Tailwind CSS.
- Develop and maintain RESTful APIs with Node.js and Express.
- Design relational database schemas and optimize queries in PostgreSQL or SQL.
- Write clean, testable code, participate in code reviews, and collaborate via Git/GitHub.

Requirements:
- Bachelor's degree in Computer Science or related field (or equivalent practical projects).
- Solid understanding of Data Structures, Algorithms, and OOP principles.
- Experience with React, TypeScript, Node.js, REST APIs, and SQL databases.
- Bonus: Familiarity with Docker, CI/CD, unit testing (Jest/Vitest), or cloud platforms (AWS/GCP).`;
