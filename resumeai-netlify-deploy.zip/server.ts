import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type, ThinkingLevel, GenerateContentResponse } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const CHAT_MODEL = process.env.CHAT_MODEL || process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const FAST_STRUCTURED_MODEL = process.env.FAST_MODEL || process.env.GEMINI_MODEL || 'gemini-2.5-flash';

function getGeminiClient(customApiKey?: string): GoogleGenAI {
  const apiKey = (customApiKey && customApiKey.trim()) || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in Netlify environment variables or app settings.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'resumeai-smart-career-assistant',
      },
    },
  });
}

function cleanBase64Pdf(dataUrlOrBase64: string): string {
  const commaIdx = dataUrlOrBase64.indexOf(',');
  return commaIdx !== -1 ? dataUrlOrBase64.slice(commaIdx + 1) : dataUrlOrBase64;
}

function extractErrorMessage(err: unknown): { status: number; message: string } {
  const raw = err instanceof Error ? err.message : String(err);
  if (raw.includes('GEMINI_API_KEY')) {
    return { status: 401, message: 'Server Gemini API key is missing. Please configure GEMINI_API_KEY in Netlify Site Settings > Environment variables, or enter your API key directly in the app Settings.' };
  }
  if (raw.includes('API_KEY_INVALID') || raw.includes('403') || raw.includes('PERMISSION_DENIED')) {
    return { status: 403, message: 'Gemini API key is invalid or lacks permission. Please verify your API key in app Settings or Netlify environment variables.' };
  }
  if (raw.includes('RESOURCE_EXHAUSTED') || raw.includes('429')) {
    return { status: 429, message: 'Gemini API rate limit reached. Please wait a moment and try again.' };
  }
  if (raw.includes('404') && raw.includes('models/')) {
    return { status: 404, message: `Model not found (${raw}). Try setting FAST_MODEL=gemini-2.5-flash in environment variables.` };
  }
  return { status: 500, message: raw || 'An unexpected error occurred while processing your AI request.' };
}

async function withRetry<T>(fn: () => Promise<T>, retries = 2): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const started = Date.now();
    try {
      const result = await fn();
      console.log(`[Gemini] attempt ${attempt + 1} succeeded in ${Date.now() - started}ms`);
      return result;
    } catch (err) {
      lastError = err;
      const msg = err instanceof Error ? err.message : String(err);
      console.error(`[Gemini] attempt ${attempt + 1} failed in ${Date.now() - started}ms:`, msg);
      const isTransient = msg.includes('503') || msg.includes('500') || msg.includes('ECONNRESET') || msg.includes('429');
      if (!isTransient || attempt === retries) {
        throw err;
      }
      await new Promise((r) => setTimeout(r, 600 * Math.pow(2, attempt)));
    }
  }
  throw lastError;
}

export function createExpressApp() {
  const app = express();
  app.use(express.json({ limit: '15mb' }));

  // CORS support
  app.use((_req: Request, res: Response, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, x-gemini-api-key');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    if (_req.method === 'OPTIONS') {
      res.sendStatus(200);
      return;
    }
    next();
  });

  const apiRouter = express.Router();

  apiRouter.get(['/health', '/api/health'], (_req: Request, res: Response) => {
    const hasServerKey = Boolean(process.env.GEMINI_API_KEY);
    res.json({
      ok: true,
      hasServerKey,
      chatModel: CHAT_MODEL,
      fastModel: FAST_STRUCTURED_MODEL,
      platform: process.env.NETLIFY ? 'netlify' : 'standalone',
    });
  });

  // 1. AI Resume Builder - Generate / Regenerate structured resume (supports SSE streaming)
  apiRouter.post(['/resume/generate', '/api/resume/generate'], async (req: Request, res: Response) => {
    const wantsStream = Boolean(req.body?.stream);
    try {
      const clientKey = (req.headers['x-gemini-api-key'] as string | undefined) || (req.query?.apiKey as string | undefined);
      const ai = getGeminiClient(clientKey);
      const input = req.body;
      if (!input || !String(input.fullName || '').trim() || !String(input.email || '').trim()) {
        res.status(400).json({ error: 'Full name and email are required to generate a resume.' });
        return;
      }

      const hasObjective = Boolean(String(input.careerObjectiveInput || '').trim());
      const hasEducation = Boolean(String(input.educationRaw || '').trim());
      const hasSkills = Boolean(String(input.skillsRaw || '').trim());
      const hasProjects = Boolean(String(input.projectsRaw || '').trim());
      const hasInternships = Boolean(String(input.internshipsRaw || '').trim());
      const hasCertifications = Boolean(String(input.certificationsRaw || '').trim());
      const hasAchievements = Boolean(String(input.achievementsRaw || '').trim());

      const prompt = `Structure and polish a professional ATS-ready resume strictly from the user's supplied details.
Target Role: ${input.targetRole || 'Not specified'}
Experience Level: ${input.experienceLevel || 'Fresher'}
${input.customInstruction ? `Customization Request: ${input.customInstruction}\n` : ''}
User Input:
- Name: ${input.fullName}
- Email: ${input.email}
- Phone: ${input.phone || ''}
- Location: ${input.location || ''}
- LinkedIn: ${input.linkedin || ''}
- Portfolio/GitHub: ${input.portfolio || ''}
- Career Objective Input: ${hasObjective ? input.careerObjectiveInput : 'NONE'}
- Education Input: ${hasEducation ? input.educationRaw : 'NONE'}
- Skills Input: ${hasSkills ? input.skillsRaw : 'NONE'}
- Projects Input: ${hasProjects ? input.projectsRaw : 'NONE'}
- Internships / Experience Input: ${hasInternships ? input.internshipsRaw : 'NONE'}
- Certifications Input: ${hasCertifications ? input.certificationsRaw : 'NONE'}
- Achievements Input: ${hasAchievements ? input.achievementsRaw : 'NONE'}

STRICT RULES:
1. Never invent qualifications, degrees, GPAs, institutions, companies, links, certifications, or achievements not present in User Input.
2. If an input section is NONE, return an empty array [] (for list sections) or empty string "" (for careerObjective).
3. Write a concise 2-sentence Professional Summary grounded only in the supplied skills, education, projects, or experience. If Career Objective Input is provided (not NONE), also return a polished Career Objective; otherwise return "" for careerObjective.
4. Rewrite project and internship points into 2-3 concise, active-voice bullet points starting with strong action verbs.`;

      const requestParams = {
        model: FAST_STRUCTURED_MODEL,
        contents: prompt,
        config: {
          systemInstruction:
            'You are a concise, accurate resume writer for students, freshers, and professionals. Never fabricate credentials.',
          thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING, description: 'Concise 2-sentence professional summary grounded in provided info.' },
              careerObjective: { type: Type.STRING, description: 'Polished career objective if supplied, otherwise empty string.' },
              education: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    degree: { type: Type.STRING },
                    institution: { type: Type.STRING },
                    duration: { type: Type.STRING },
                    grade: { type: Type.STRING },
                    highlights: { type: Type.STRING },
                  },
                  required: ['degree', 'institution', 'duration', 'grade', 'highlights'],
                },
              },
              skills: {
                type: Type.OBJECT,
                properties: {
                  technical: { type: Type.ARRAY, items: { type: Type.STRING } },
                  tools: { type: Type.ARRAY, items: { type: Type.STRING } },
                  soft: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: ['technical', 'tools', 'soft'],
              },
              projects: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    techStack: { type: Type.STRING },
                    link: { type: Type.STRING },
                    bullets: { type: Type.ARRAY, items: { type: Type.STRING } },
                  },
                  required: ['title', 'techStack', 'link', 'bullets'],
                },
              },
              internships: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    role: { type: Type.STRING },
                    company: { type: Type.STRING },
                    duration: { type: Type.STRING },
                    location: { type: Type.STRING },
                    bullets: { type: Type.ARRAY, items: { type: Type.STRING } },
                  },
                  required: ['role', 'company', 'duration', 'location', 'bullets'],
                },
              },
              certifications: { type: Type.ARRAY, items: { type: Type.STRING } },
              achievements: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: [
              'summary',
              'careerObjective',
              'education',
              'skills',
              'projects',
              'internships',
              'certifications',
              'achievements',
            ],
          },
        },
      };

      const cleanStr = (v: unknown) => {
        if (typeof v !== 'string') return '';
        const t = v.trim();
        return /^(not specified|none|n\/a|na)$/i.test(t) ? '' : t;
      };

      const sanitizeGenerated = (raw: Record<string, unknown>) => ({
        summary: cleanStr(raw.summary),
        careerObjective: hasObjective ? cleanStr(raw.careerObjective) : '',
        education:
          hasEducation && Array.isArray(raw.education)
            ? raw.education.map((e: Record<string, unknown>) => ({
                degree: cleanStr(e.degree),
                institution: cleanStr(e.institution),
                duration: cleanStr(e.duration),
                grade: cleanStr(e.grade),
                highlights: cleanStr(e.highlights),
              }))
            : [],
        skills:
          hasSkills && raw.skills && typeof raw.skills === 'object'
            ? raw.skills
            : { technical: [], tools: [], soft: [] },
        projects:
          hasProjects && Array.isArray(raw.projects)
            ? raw.projects.map((p: Record<string, unknown>) => ({
                title: cleanStr(p.title),
                techStack: cleanStr(p.techStack),
                link: cleanStr(p.link),
                bullets: Array.isArray(p.bullets) ? p.bullets.map(cleanStr).filter(Boolean) : [],
              }))
            : [],
        internships:
          hasInternships && Array.isArray(raw.internships)
            ? raw.internships.map((i: Record<string, unknown>) => ({
                role: cleanStr(i.role),
                company: cleanStr(i.company),
                duration: cleanStr(i.duration),
                location: cleanStr(i.location),
                bullets: Array.isArray(i.bullets) ? i.bullets.map(cleanStr).filter(Boolean) : [],
              }))
            : [],
        certifications:
          hasCertifications && Array.isArray(raw.certifications)
            ? raw.certifications.map(cleanStr).filter(Boolean)
            : [],
        achievements:
          hasAchievements && Array.isArray(raw.achievements)
            ? raw.achievements.map(cleanStr).filter(Boolean)
            : [],
      });

      if (wantsStream) {
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');

        let clientAborted = false;
        res.on('close', () => {
          if (!res.writableEnded) {
            clientAborted = true;
          }
        });

        res.write(`data: ${JSON.stringify({ stage: 'Generating your professional resume...' })}\n\n`);

        const stream = await withRetry(() => ai.models.generateContentStream(requestParams));
        let fullText = '';
        let chunkCount = 0;

        for await (const chunk of stream) {
          if (clientAborted) break;
          const c = chunk as GenerateContentResponse;
          if (c.text) {
            fullText += c.text;
            chunkCount += 1;
            if (chunkCount === 2) {
              res.write(`data: ${JSON.stringify({ stage: 'Structuring skills and experience...' })}\n\n`);
            } else if (chunkCount === 6) {
              res.write(`data: ${JSON.stringify({ stage: 'Polishing resume sections...' })}\n\n`);
            }
          }
        }

        if (clientAborted) return;

        const trimmed = fullText.trim();
        if (!trimmed) {
          res.write(`data: ${JSON.stringify({ error: 'Gemini AI returned an empty response. Please try again.' })}\n\n`);
          res.end();
          return;
        }

        const parsed = JSON.parse(trimmed) as Record<string, unknown>;
        const generated = sanitizeGenerated(parsed);
        res.write(`data: ${JSON.stringify({ done: true, generated })}\n\n`);
        res.end();
        return;
      }

      const response = await withRetry(() => ai.models.generateContent(requestParams));
      const trimmed = (response.text ?? '').trim();
      if (!trimmed) {
        res.status(502).json({ error: 'Gemini AI returned an empty response. Please try again.' });
        return;
      }
      const parsed = JSON.parse(trimmed) as Record<string, unknown>;
      const generated = sanitizeGenerated(parsed);
      res.json({ generated });
    } catch (err) {
      const { status, message } = extractErrorMessage(err);
      console.error('[POST /api/resume/generate] Error:', message);
      if (wantsStream && res.headersSent) {
        res.write(`data: ${JSON.stringify({ error: message })}\n\n`);
        res.end();
      } else {
        res.status(status).json({ error: message });
      }
    }
  });

  // 2. AI Resume Analyzer (PDF or Text)
  apiRouter.post(['/resume/analyze', '/api/resume/analyze'], async (req: Request, res: Response) => {
    try {
      const clientKey = (req.headers['x-gemini-api-key'] as string | undefined) || (req.query?.apiKey as string | undefined);
      const ai = getGeminiClient(clientKey);
      const { pdfBase64, resumeText, targetRole } = req.body as {
        pdfBase64?: string;
        resumeText?: string;
        targetRole?: string;
      };

      if (!pdfBase64 && (!resumeText || !resumeText.trim())) {
        res.status(400).json({ error: 'Please upload a PDF resume or paste resume text to analyze.' });
        return;
      }

      const instructionPrompt = `Perform a thorough, encouraging, and practical resume audit.
${targetRole ? `Target Role: ${targetRole}` : 'Evaluate for general industry/fresher readiness.'}
Identify:
1. Overall score (0-100) and breakdown scores (0-100) for impact, clarity, formatting, skillsRelevance, and grammar.
2. Key strengths already present.
3. Missing skills or keywords expected for this profile/target role.
4. Specific grammar, spelling, or phrasing mistakes with exact corrections.
5. Weak bullet descriptions found in the resume with rewritten, impact-focused improved versions.
6. Formatting, structure, or length issues.
7. Prioritized actionable improvement tips tailored to students, freshers, or job seekers.`;

      const contents = pdfBase64
        ? {
            parts: [
              {
                inlineData: {
                  mimeType: 'application/pdf',
                  data: cleanBase64Pdf(pdfBase64),
                },
              },
              { text: instructionPrompt },
            ],
          }
        : `${instructionPrompt}\n\nRESUME CONTENT:\n${resumeText}`;

      const response = await withRetry(() =>
        ai.models.generateContent({
          model: FAST_STRUCTURED_MODEL,
          contents,
          config: {
            systemInstruction:
              'You are a senior technical recruiter and career coach. Give honest, constructive, beginner-friendly feedback with concrete rewrites.',
            thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                overallScore: { type: Type.INTEGER },
                sectionScores: {
                  type: Type.OBJECT,
                  properties: {
                    impact: { type: Type.INTEGER },
                    clarity: { type: Type.INTEGER },
                    formatting: { type: Type.INTEGER },
                    skillsRelevance: { type: Type.INTEGER },
                    grammar: { type: Type.INTEGER },
                  },
                  required: ['impact', 'clarity', 'formatting', 'skillsRelevance', 'grammar'],
                },
                summaryVerdict: { type: Type.STRING },
                strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
                missingSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
                grammarIssues: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      original: { type: Type.STRING },
                      correction: { type: Type.STRING },
                      reason: { type: Type.STRING },
                    },
                    required: ['original', 'correction', 'reason'],
                  },
                },
                weakDescriptions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      section: { type: Type.STRING },
                      current: { type: Type.STRING },
                      improved: { type: Type.STRING },
                      explanation: { type: Type.STRING },
                    },
                    required: ['section', 'current', 'improved', 'explanation'],
                  },
                },
                formattingIssues: { type: Type.ARRAY, items: { type: Type.STRING } },
                actionableTips: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: [
                'overallScore',
                'sectionScores',
                'summaryVerdict',
                'strengths',
                'missingSkills',
                'grammarIssues',
                'weakDescriptions',
                'formattingIssues',
                'actionableTips',
              ],
            },
          },
        })
      );

      const analysis = JSON.parse((response.text ?? '{}').trim());
      res.json({ analysis });
    } catch (err) {
      const { status, message } = extractErrorMessage(err);
      res.status(status).json({ error: message });
    }
  });

  // 3. AI Resume Chatbot (Streaming SSE)
  apiRouter.post(['/chat', '/api/chat'], async (req: Request, res: Response) => {
    try {
      const clientKey = (req.headers['x-gemini-api-key'] as string | undefined) || (req.query?.apiKey as string | undefined);
      const ai = getGeminiClient(clientKey);
      const { messages, resumeContext } = req.body as {
        messages: Array<{ role: 'user' | 'assistant'; content: string }>;
        resumeContext?: string;
      };

      if (!Array.isArray(messages) || messages.length === 0) {
        res.status(400).json({ error: 'Messages array is required.' });
        return;
      }

      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');

      const history = messages.slice(0, -1).map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      }));
      const latestUserMessage = messages[messages.length - 1].content;

      const systemInstruction = `You are ResumeAI, a warm, polite, beginner-friendly Smart Career Assistant created to help students, freshers, and professionals build standout resumes, prepare for job applications, optimize LinkedIn profiles, and succeed in interviews.

Communication style:
- Polite, encouraging, clear, and structured.
- Use simple explanations paired with concrete, actionable examples (e.g., before/after bullet points, templates, or step-by-step checklists).
- Focus especially on helping students and freshers highlight college projects, coursework, hackathons, certifications, and internships when they lack full-time experience.
- Use clean markdown headings, bullet lists, and bold emphasis for readability.
${resumeContext ? `\nThe user has attached their current resume for personalized advice:\n---\n${resumeContext}\n---` : ''}`;

      const chat = ai.chats.create({
        model: CHAT_MODEL,
        history,
        config: {
          systemInstruction,
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        },
      });

      const streamResponse = await chat.sendMessageStream({
        message: latestUserMessage,
      });

      for await (const chunk of streamResponse) {
        const c = chunk as GenerateContentResponse;
        if (c.text) {
          res.write(`data: ${JSON.stringify({ text: c.text })}\n\n`);
        }
      }
      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (err) {
      const { message } = extractErrorMessage(err);
      if (!res.headersSent) {
        res.status(500).json({ error: message });
      } else {
        res.write(`data: ${JSON.stringify({ error: message })}\n\n`);
        res.end();
      }
    }
  });

  // 4. ATS Resume Checker
  apiRouter.post(['/ats/check', '/api/ats/check'], async (req: Request, res: Response) => {
    try {
      const clientKey = (req.headers['x-gemini-api-key'] as string | undefined) || (req.query?.apiKey as string | undefined);
      const ai = getGeminiClient(clientKey);
      const { pdfBase64, resumeText, jobDescription } = req.body as {
        pdfBase64?: string;
        resumeText?: string;
        jobDescription?: string;
      };

      if (!pdfBase64 && (!resumeText || !resumeText.trim())) {
        res.status(400).json({ error: 'Please provide a resume (PDF or text).' });
        return;
      }
      if (!jobDescription || !jobDescription.trim()) {
        res.status(400).json({ error: 'Please paste a target job description to compare against.' });
        return;
      }

      const prompt = `Analyze this resume for Applicant Tracking System (ATS) compatibility against the provided Job Description.
JOB DESCRIPTION:
${jobDescription}

Evaluate:
1. Overall ATS compatibility score (0-100) and keyword match percentage (0-100).
2. Matched keywords/skills present in both resume and JD.
3. Missing high-priority keywords/skills from the JD that the candidate should incorporate (if truthful).
4. Section heading audit (checking standard ATS-parseable headings like Summary, Experience, Education, Skills, Projects).
5. ATS formatting & parsing checks (single-column readability, contact info placement, date formatting, avoidance of non-standard graphics/tables).
6. Concrete tailoring suggestions to raise the match rate.`;

      const contents = pdfBase64
        ? {
            parts: [
              {
                inlineData: {
                  mimeType: 'application/pdf',
                  data: cleanBase64Pdf(pdfBase64),
                },
              },
              { text: prompt },
            ],
          }
        : `${prompt}\n\nRESUME TEXT:\n${resumeText}`;

      const response = await withRetry(() =>
        ai.models.generateContent({
          model: FAST_STRUCTURED_MODEL,
          contents,
          config: {
            systemInstruction:
              'You are an ATS parsing engine and technical recruiter. Provide accurate keyword comparison and practical ATS formatting advice.',
            thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                atsScore: { type: Type.INTEGER },
                keywordMatchRate: { type: Type.INTEGER },
                verdict: { type: Type.STRING },
                matchedKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
                missingKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
                headingAudit: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      heading: { type: Type.STRING },
                      status: { type: Type.STRING, description: "Must be 'pass', 'warn', or 'fail'" },
                      recommendation: { type: Type.STRING },
                    },
                    required: ['heading', 'status', 'recommendation'],
                  },
                },
                formattingChecks: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      check: { type: Type.STRING },
                      passed: { type: Type.BOOLEAN },
                      detail: { type: Type.STRING },
                    },
                    required: ['check', 'passed', 'detail'],
                  },
                },
                tailoringSuggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: [
                'atsScore',
                'keywordMatchRate',
                'verdict',
                'matchedKeywords',
                'missingKeywords',
                'headingAudit',
                'formattingChecks',
                'tailoringSuggestions',
              ],
            },
          },
        })
      );

      const atsResult = JSON.parse((response.text ?? '{}').trim());
      res.json({ atsResult });
    } catch (err) {
      const { status, message } = extractErrorMessage(err);
      res.status(status).json({ error: message });
    }
  });

  // 5. Interview Preparation - Generate Technical & HR questions
  apiRouter.post(['/interview/generate', '/api/interview/generate'], async (req: Request, res: Response) => {
    try {
      const clientKey = (req.headers['x-gemini-api-key'] as string | undefined) || (req.query?.apiKey as string | undefined);
      const ai = getGeminiClient(clientKey);
      const { pdfBase64, resumeText, targetRole, experienceLevel, focus } = req.body as {
        pdfBase64?: string;
        resumeText?: string;
        targetRole?: string;
        experienceLevel?: string;
        focus?: 'mixed' | 'technical' | 'hr';
      };

      const prompt = `Generate a tailored interview preparation kit.
Target Role: ${targetRole || 'Software Developer / Early-Career Role'}
Candidate Experience Level: ${experienceLevel || 'Fresher'}
Focus: ${focus === 'technical' ? 'Mostly Technical & Project Deep-Dive' : focus === 'hr' ? 'Mostly HR & Behavioral' : 'Balanced mix of 4 Technical and 4 HR/Behavioral questions'}

If a resume is attached or pasted, reference specific projects, skills, or internships from the resume in the technical and behavioral questions!
For each question provide:
- category ('Technical' or 'HR')
- difficulty ('Beginner', 'Intermediate', or 'Advanced')
- question
- whyAsked (what the interviewer is looking for)
- keyPoints (3-4 bullet points to cover)
- sampleAnswer (a natural, strong model answer suitable for a ${experienceLevel || 'Fresher'})
- tips (concise delivery tip)`;

      const contents = pdfBase64
        ? {
            parts: [
              {
                inlineData: {
                  mimeType: 'application/pdf',
                  data: cleanBase64Pdf(pdfBase64),
                },
              },
              { text: prompt },
            ],
          }
        : resumeText && resumeText.trim()
        ? `${prompt}\n\nCANDIDATE RESUME:\n${resumeText}`
        : prompt;

      const response = await withRetry(() =>
        ai.models.generateContent({
          model: FAST_STRUCTURED_MODEL,
          contents,
          config: {
            systemInstruction:
              'You are an experienced hiring manager and interview coach helping students, freshers, and professionals prepare confidently for interviews.',
            thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                roleFocus: { type: Type.STRING },
                overviewTips: { type: Type.ARRAY, items: { type: Type.STRING } },
                questions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      category: { type: Type.STRING, description: "Either 'Technical' or 'HR'" },
                      difficulty: { type: Type.STRING, description: "'Beginner', 'Intermediate', or 'Advanced'" },
                      question: { type: Type.STRING },
                      whyAsked: { type: Type.STRING },
                      keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
                      sampleAnswer: { type: Type.STRING },
                      tips: { type: Type.STRING },
                    },
                    required: ['id', 'category', 'difficulty', 'question', 'whyAsked', 'keyPoints', 'sampleAnswer', 'tips'],
                  },
                },
              },
              required: ['roleFocus', 'overviewTips', 'questions'],
            },
          },
        })
      );

      const prepKit = JSON.parse((response.text ?? '{}').trim());
      res.json({ prepKit });
    } catch (err) {
      const { status, message } = extractErrorMessage(err);
      res.status(status).json({ error: message });
    }
  });

  // 6. Interview Answer Practice Evaluator
  apiRouter.post(['/interview/evaluate', '/api/interview/evaluate'], async (req: Request, res: Response) => {
    try {
      const clientKey = (req.headers['x-gemini-api-key'] as string | undefined) || (req.query?.apiKey as string | undefined);
      const ai = getGeminiClient(clientKey);
      const { question, userAnswer, targetRole } = req.body as {
        question: string;
        userAnswer: string;
        targetRole?: string;
      };

      if (!question || !userAnswer || !userAnswer.trim()) {
        res.status(400).json({ error: 'Please write your practice answer before requesting feedback.' });
        return;
      }

      const prompt = `Evaluate this candidate's practice interview answer.
Target Role: ${targetRole || 'General'}
Interview Question: ${question}
Candidate's Practice Answer: ${userAnswer}

Give a fair, encouraging score (0-100), a short verdict, 2-3 specific strengths, 2-3 clear improvements, and a refined version of their own answer keeping their real voice.`;

      const response = await withRetry(() =>
        ai.models.generateContent({
          model: FAST_STRUCTURED_MODEL,
          contents: prompt,
          config: {
            systemInstruction:
              'You are a supportive, practical interview coach giving constructive feedback to help job seekers communicate clearly using the STAR method and technical precision.',
            thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                score: { type: Type.INTEGER },
                verdict: { type: Type.STRING },
                strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
                improvements: { type: Type.ARRAY, items: { type: Type.STRING } },
                refinedAnswer: { type: Type.STRING },
              },
              required: ['score', 'verdict', 'strengths', 'improvements', 'refinedAnswer'],
            },
          },
        })
      );

      const evaluation = JSON.parse((response.text ?? '{}').trim());
      res.json({ evaluation });
    } catch (err) {
      const { status, message } = extractErrorMessage(err);
      res.status(status).json({ error: message });
    }
  });

  // Mount API router across supported endpoints for Netlify serverless & local dev
  app.use('/api', apiRouter);
  app.use('/.netlify/functions/api', apiRouter);
  app.use('/', apiRouter);

  return app;
}

export async function startServer() {
  const app = createExpressApp();

  // Vite dev middleware vs Production static serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ResumeAI server running on http://0.0.0.0:${PORT}`);
  });
}

// Automatically start server only when executed directly via Node / tsx
if (!process.env.NETLIFY && !process.env.AWS_LAMBDA_FUNCTION_NAME) {
  const isDirect = Boolean(
    process.argv[1] && (process.argv[1].endsWith('server.ts') || process.argv[1].endsWith('server.js'))
  );
  if (isDirect) {
    startServer().catch((err) => {
      console.error('Failed to start ResumeAI server:', err);
      process.exit(1);
    });
  }
}
